"""Мини-платформер на pygame с процедурной графикой и скинами (референс — Super Mario).

Управление (суша):
    ← →        — идти
    ↑ / Пробел — прыжок
Управление (вода, уровень 4):
    ← → ↑ ↓    — плыть в любую сторону
Общее:
    R          — рестарт (после победы/поражения)
    Esc        — выход

Четыре уровня:
    1 — базовый;
    2 — движущиеся платформы и новые враги;
    3 — землетрясения (тряска мешает движению) и стреляющие враги;
    4 — подводный мир: свободное плавание, водные враги, кораллы/водоросли/пузыри.

Скины берутся из папки assets/, анимация рисуется кодом.
Спрайты стрелков и водных врагов пока процедурные — заменятся, если положить
соответствующие assets/<name>.png.
"""

import asyncio
import json
import math
import os
import random
import sys
import pygame

_np = None                          # numpy грузится лениво (синтез звука), чтобы не тянуть его в веб
_HAS_NUMPY = False
_numpy_tried = False


def _ensure_numpy():
    global _np, _HAS_NUMPY, _numpy_tried
    if not _numpy_tried:
        _numpy_tried = True
        try:
            import importlib
            _np = importlib.import_module("numpy")   # через importlib — pygbag не тянет numpy в веб-сборку
            _HAS_NUMPY = True
        except Exception:
            _HAS_NUMPY = False
    return _HAS_NUMPY

# --- Параметры мира ---
WIDTH, HEIGHT = 960, 540
FPS = 60
TILE = 40
SAVE_FILE = "savegame.json"
SAVE_KEY = "bubuza_save"            # ключ localStorage в веб-сборке (pygbag)
IS_WEB = sys.platform == "emscripten"

GRAVITY = 0.7
MOVE_SPEED = 4.6
JUMP_SPEED = 13.6
HIGH_JUMP_MULT = 1.5        # «высокий прыжок» (предмет «сырок», ур.13)
MAX_FALL = 16.0
STOMP_BOUNCE = 9.5
BOSS_STOMP_BOUNCE = 19.0    # отскок после стомпа босса (вдвое — чтобы не упасть обратно на него)
INVULN_FRAMES = 90
DEATH_FRAMES = 16
EFFECT_FRAMES = 28
RESPAWN_LOCK_FRAMES = 30
TOAST_FRAMES = 150          # ненавязчивое уведомление (~2.5 с)

COIN_SCORE = 100
STOMP_SCORE = 200
MAX_LEVEL = 15              # всего уровней (11-13 — сырные; 14 — радужный; 15 — босс-единорог)

LEVEL_H = HEIGHT
GROUND_TOP = 400
GROUND_H = HEIGHT - GROUND_TOP

WALK_SPEED = 1.6
FLY_SPEED = 1.3
FLY_STEP = 0.05
JUMP_ENEMY_SPEED = 10.5
JUMP_ENEMY_WAIT = 45

# Землетрясение (уровень 3)
QUAKE_MIN_S, QUAKE_MAX_S = 5.0, 10.0
QUAKE_DUR_S = 3.0
QUAKE_AMP = 11
SHAKE_MARGIN = 16

# Стрелки и снаряды
SHOOT_INTERVAL = 95
PROJ_SPEED = 5.2
PROJ_R = 7

# Подводный мир (уровень 4)
SWIM_SPEED = 3.4
SWIM_ACCEL = 0.2
WATER_SURFACE = 66
SEA_FLOOR = HEIGHT - 46
FISH_SPEED = 1.9

# Ледяной уровень (9)
ICE_ACCEL = 0.09            # скользкость (чем меньше — тем более скользко)
ICICLE_INTERVAL = 48        # период появления сосулек
ICICLE_GRAV = 0.45
ICICLE_MAX = 11.0
ICICLE_W, ICICLE_H = 18, 34
ICE_SKY = (175, 205, 230)

# Лес (уровень 7): падающие деревья
TREE_SHAKE_TIME = 55         # предупреждение-шатание (~0.9 с)
TREE_FALL_SPEED = 3.4        # градусов за кадр (падение ~26 кадров)
TREE_TRIGGER_DIST = 240      # дистанция, на которой дерево начинает падать
TREE_TRUNK_W = 18

# Цыплёнок-усилитель и супер-форма (уровень 6)
CHICK_SPEED = 3.1
SUPER_SHOT_CD = 18           # ~0.3 с
SUPER_SHOT_SPEED = 13.0
SUPER_SHOT_R = 9

# Босс (уровень 7)
BOSS_HP = 3
BOSS_HOVER_Y = GROUND_TOP - 150
BOSS_MOVE_SPEED = 2.3
BOSS_MOVE_TIME = 130
BOSS_TELE_TIME = 45
BOSS_SLAM_GRAV = 1.2
BOSS_SLAM_MAX = 22.0
BOSS_STUN_TIME = 110
BOSS_INVULN = 45

# Босс-муравей (уровень 10): бегает по полу, плюётся жёлтой кислотой (лужи), уязвим после залпа
ANT_W, ANT_H = 124, 64
ANT_RUN_SPEED = 3.4
ANT_RUN_TIME = 140          # сколько бегает за игроком до залпа
ANT_AIM_TIME = 42           # телеграф перед плевком
ANT_SPIT_COUNT = 3          # капель в залпе (веером)
ANT_VULN_TIME = 150         # окно уязвимости после залпа (~2.5 c)
ANT_INVULN = 50             # неуязвимость муравья после удара
ANT_STOP_MARGIN = 18        # запас, на который муравей выходит из-под кирпича (голова открыта)
ANT_HEAD_CLEARANCE = 46     # мин. просвет над головой для прыжка игрока (меньше — «низкий» кирпич)
SPIT_SPEED = 6.6
SPIT_GRAV = 0.30
SPIT_R = 8
PUDDLE_W, PUDDLE_H = 76, 12
PUDDLE_LIFE = 5 * FPS       # лужа держится 5 секунд

# Сырная поляна (уровень 11): мыши
MOUSE_WHITE_SPEED = 3.0     # белая мышь — быстрая
MOUSE_GRAY_SPEED = 1.25     # серая мышь — медленная, толстая
MOUSE_GRAY_HP = 2           # серую надо стомпнуть дважды

# Сырный дом / подвал (уровни 12-13): лазерная точка + кот-охотник
LASER_SPEED = 3.4           # как быстро точка догоняет игрока
LASER_LOCK = 16             # радиус «попадания» точки по игроку
CAT_RUN_SPEED = 4.4         # кот бежит за лазерной точкой по полу
CAT_AIM_TIME = 60           # 1 c от попадания лазера до прыжка
CAT_RECOVER_TIME = 38       # пауза после приземления
CAT_LEAP_VY = -14.0         # стартовая вертикаль прыжка
CAT_LEAP_VX_MAX = 8.5       # макс. горизонтальная скорость прыжка
CAT_GRAV = 0.72
CAT_W, CAT_H = 60, 50
CAT_BURST_MIN, CAT_BURST_MAX = 5.0, 10.0    # раз в 5-10 c — рывок
CAT_BURST_SPEED = 2.7       # множитель скорости точки в рывке
CAT_BURST_RUN = 1.5         # множитель скорости кота в рывке
CAT_BURST_AIM = 30          # в рывке прыжок через 0.5 c вместо 1 c

# Сырный подвал (уровень 13): катящиеся сыры-валуны
BOULDER_R = 60             # радиус валуна (большой — нужен высокий прыжок)
BOULDER_SPEED = 4.7         # катится справа налево
BOULDER_MIN_S, BOULDER_MAX_S = 2.3, 3.8     # интервал появления, c

# Радужный мир (уровень 14): крутящиеся колёса-платформы над ямами
WHEEL_R = 70                # радиус колеса
SPOKE_W, SPOKE_H = 84, 16   # лопасть-платформа на ободе
WHEEL_SPOKES = 4            # лопастей на колесо
WHEEL_SPEED = 0.02          # рад/кадр (верхняя лопасть едет вправо — помогает игроку)

# Босс-единорог (уровень 15, финал): ходит → заряжает рог 0.5 c → радужный луч во всю ширину → уязвим
UNI_W, UNI_H = 170, 100
UNI_HP = 4                  # сердец у финального босса
UNI_MOVE_SPEED = 2.6
UNI_MOVE_TIME = 150         # сколько преследует игрока до выстрела
UNI_CHARGE_TIME = int(0.5 * FPS)   # 0.5 c телеграфа перед лучом (как просили)
UNI_BEAM_TIME = 46          # длительность луча (~0.77 c)
UNI_VULN_TIME = 150         # окно уязвимости после луча (~2.5 c)
UNI_INVULN = 50             # неуязвимость единорога после удара
UNI_HURT_TIME = int(0.7 * FPS)     # стоит на месте ~0.7 c после удара по голове
UNI_EDGE_MARGIN = 220       # не заходит под боковые подъёмные уступы
UNI_BEAM_HALF = 22          # полутолщина направленного луча (единорог целится в игрока)
UNI_BEAM_LEN = 1600         # длина луча — через весь экран

SPRITES = {
    "bubuza": 46, "gulya": 40, "gus": 40, "jaba": 38,
    "kot": 34, "zombie": 44, "popug": 40, "axilotle": 38,
    "gunner": 36, "bomber": 32, "fish": 28, "emedusa": 38, "boss": 50,
    "chick": 24, "pug": 34, "mouse_white": 24, "mouse_gray": 30, "unicorn": 38,
}

SKY = (110, 195, 245)
HILL = (95, 175, 80)
HILL_DARK = (80, 155, 68)
WATER_TOP_COL = (40, 150, 200)
WATER_BOT_COL = (15, 70, 130)


# =====================================================================
#  Текстуры окружения + процедурные заглушки врагов
# =====================================================================

def make_ground_texture():
    s = pygame.Surface((TILE, TILE))
    s.fill((155, 100, 60))
    pygame.draw.rect(s, (90, 175, 70), (0, 0, TILE, 11))
    pygame.draw.rect(s, (70, 150, 58), (0, 9, TILE, 3))
    rng = random.Random(11)
    for _ in range(14):
        x, y = rng.randint(0, TILE - 5), rng.randint(14, TILE - 5)
        pygame.draw.rect(s, (125, 78, 46), (x, y, 4, 4))
    pygame.draw.rect(s, (120, 78, 46), (0, 0, TILE, TILE), 1)
    return s


def make_brick_texture():
    s = pygame.Surface((TILE, TILE))
    s.fill((200, 110, 70))
    mortar = (235, 200, 160)
    pygame.draw.rect(s, mortar, (0, 0, TILE, TILE), 2)
    pygame.draw.line(s, mortar, (0, TILE // 2), (TILE, TILE // 2), 2)
    pygame.draw.line(s, mortar, (TILE // 2, 0), (TILE // 2, TILE // 2), 2)
    pygame.draw.line(s, mortar, (TILE // 4, TILE // 2), (TILE // 4, TILE), 2)
    pygame.draw.line(s, mortar, (3 * TILE // 4, TILE // 2), (3 * TILE // 4, TILE), 2)
    return s


def make_sand_texture():
    s = pygame.Surface((TILE, TILE))
    s.fill((225, 205, 140))
    pygame.draw.rect(s, (205, 180, 120), (0, 0, TILE, 6))
    rng = random.Random(5)
    for _ in range(18):
        x, y = rng.randint(0, TILE - 4), rng.randint(2, TILE - 4)
        pygame.draw.rect(s, (200, 175, 115), (x, y, 3, 3))
    return s


def make_ice_texture():
    s = pygame.Surface((TILE, TILE))
    s.fill((208, 232, 246))
    pygame.draw.rect(s, (235, 248, 255), (0, 0, TILE, 7))         # светлый верх
    pygame.draw.rect(s, (176, 208, 232), (0, 0, TILE, TILE), 1)
    pygame.draw.line(s, (236, 247, 255), (7, 12), (16, 22), 2)    # блики/трещины
    pygame.draw.line(s, (236, 247, 255), (26, 9), (32, 18), 2)
    pygame.draw.line(s, (184, 214, 236), (10, 28), (22, 34), 1)
    return s


def make_rock_texture():
    s = pygame.Surface((TILE, TILE))
    s.fill((110, 120, 130))
    pygame.draw.rect(s, (80, 90, 100), (0, 0, TILE, TILE), 2)
    rng = random.Random(9)
    for _ in range(8):
        x, y = rng.randint(2, TILE - 8), rng.randint(2, TILE - 8)
        pygame.draw.rect(s, (95, 105, 115), (x, y, 6, 5))
    return s


def make_cloud_texture():
    s = pygame.Surface((130, 60), pygame.SRCALPHA)
    for cx, cy, r in [(34, 42, 24), (62, 30, 30), (92, 40, 26), (52, 46, 26), (104, 48, 18)]:
        pygame.draw.circle(s, (255, 255, 255), (cx, cy), r)
    return s


def make_softbrick_texture():
    s = pygame.Surface((TILE, TILE))
    s.fill((175, 130, 95))
    mortar = (140, 100, 70)
    pygame.draw.rect(s, mortar, (0, 0, TILE, TILE), 2)
    pygame.draw.line(s, mortar, (0, TILE // 2), (TILE, TILE // 2), 2)
    pygame.draw.line(s, mortar, (TILE // 2, 0), (TILE // 2, TILE), 2)
    pygame.draw.lines(s, (120, 85, 60), False,                       # трещина
                      [(8, 6), (16, 18), (10, 24), (20, 34)], 2)
    return s


def make_gunner_texture():
    w, h = 32, 36
    s = pygame.Surface((w, h), pygame.SRCALPHA)
    pygame.draw.rect(s, (95, 100, 110), (3, 20, 26, 14))
    pygame.draw.rect(s, (60, 65, 75), (3, 20, 26, 14), 2)
    pygame.draw.ellipse(s, (125, 130, 140), (4, 4, 24, 22))
    pygame.draw.ellipse(s, (70, 75, 85), (4, 4, 24, 22), 2)
    pygame.draw.rect(s, (50, 55, 65), (24, 13, 8, 7))
    pygame.draw.circle(s, (255, 80, 60), (16, 15), 5)
    pygame.draw.circle(s, (120, 20, 10), (16, 15), 5, 1)
    return s


def make_bomber_texture():
    w, h = 36, 32
    s = pygame.Surface((w, h), pygame.SRCALPHA)
    pygame.draw.line(s, (70, 75, 85), (8, 5), (28, 5), 3)
    pygame.draw.circle(s, (85, 95, 105), (18, 18), 13)
    pygame.draw.circle(s, (55, 62, 72), (18, 18), 13, 2)
    for ax, ay in [(18, 3), (18, 33), (3, 18), (33, 18)]:
        pygame.draw.circle(s, (60, 66, 76), (ax, ay), 3)
    pygame.draw.circle(s, (255, 90, 60), (18, 18), 5)
    pygame.draw.circle(s, (120, 25, 12), (18, 18), 5, 1)
    return s


def make_fish_texture():
    """Заглушка рыбы (заменится на assets/fish.png)."""
    w, h = 46, 28
    s = pygame.Surface((w, h), pygame.SRCALPHA)
    body = (240, 140, 50)
    pygame.draw.polygon(s, (235, 120, 40), [(2, 14), (16, 4), (16, 24)])     # хвост
    pygame.draw.ellipse(s, body, (12, 4, 30, 20))
    pygame.draw.polygon(s, (235, 120, 40), [(24, 4), (32, -2), (34, 6)])     # плавник
    pygame.draw.circle(s, (255, 255, 255), (36, 13), 4)
    pygame.draw.circle(s, (25, 25, 25), (37, 13), 2)
    pygame.draw.arc(s, (180, 80, 20), (30, 14, 10, 8), 3.4, 6.0, 2)
    return s


def make_emedusa_texture():
    """Заглушка злой медузы-врага (заменится на assets/emedusa.png)."""
    w, h = 34, 40
    s = pygame.Surface((w, h), pygame.SRCALPHA)
    dome = (150, 80, 200)
    pygame.draw.ellipse(s, dome, (3, 2, 28, 22))
    pygame.draw.ellipse(s, (110, 55, 160), (3, 2, 28, 22), 2)
    for i in range(5):
        x = 6 + i * 5
        pygame.draw.line(s, (175, 110, 215), (x, 20), (x + math.sin(i) * 2, 38), 3)
    pygame.draw.circle(s, (255, 255, 255), (13, 13), 4)
    pygame.draw.circle(s, (255, 255, 255), (23, 13), 4)
    pygame.draw.circle(s, (40, 10, 40), (14, 14), 2)
    pygame.draw.circle(s, (40, 10, 40), (24, 14), 2)
    pygame.draw.line(s, (60, 20, 60), (10, 9), (16, 11), 2)      # злые брови
    pygame.draw.line(s, (60, 20, 60), (24, 9), (18, 11), 2)
    return s


def make_boss_texture():
    """Заглушка босса-сосиски (заменится на assets/boss.png)."""
    w, h = 98, 48
    s = pygame.Surface((w, h), pygame.SRCALPHA)
    body = (205, 120, 95)
    dark = (150, 78, 58)
    pygame.draw.rect(s, body, (8, 9, 82, 30), border_radius=15)
    pygame.draw.rect(s, dark, (8, 9, 82, 30), 3, border_radius=15)
    pygame.draw.line(s, (240, 180, 150), (22, 17), (74, 17), 4)        # блик
    for lx in (36, 64):                                               # перетяжки сосиски
        pygame.draw.line(s, dark, (lx, 12), (lx, 36), 2)
    pygame.draw.circle(s, (255, 255, 255), (32, 22), 7)
    pygame.draw.circle(s, (255, 255, 255), (54, 22), 7)
    pygame.draw.circle(s, (25, 25, 25), (34, 23), 3)
    pygame.draw.circle(s, (25, 25, 25), (56, 23), 3)
    pygame.draw.line(s, dark, (24, 13), (36, 18), 3)                  # злые брови
    pygame.draw.line(s, dark, (62, 13), (50, 18), 3)
    pygame.draw.arc(s, (90, 40, 30), (34, 26, 26, 14), 3.4, 6.0, 3)   # рот
    return s


def make_chick_texture():
    """Заглушка цыплёнка-усилителя (заменится на assets/chick.png)."""
    w, h = 24, 24
    s = pygame.Surface((w, h), pygame.SRCALPHA)
    yellow = (255, 215, 60)
    pygame.draw.circle(s, yellow, (12, 14), 9)
    pygame.draw.circle(s, (255, 230, 110), (12, 8), 7)
    pygame.draw.polygon(s, (240, 140, 30), [(19, 9), (24, 11), (19, 13)])   # клюв
    pygame.draw.circle(s, (30, 30, 30), (14, 7), 2)
    pygame.draw.line(s, (240, 140, 30), (9, 22), (9, 24), 2)
    pygame.draw.line(s, (240, 140, 30), (15, 22), (15, 24), 2)
    return s


def make_pug_texture():
    """Заглушка летающего мопса (заменится на assets/pug.png)."""
    w, h = 36, 32
    s = pygame.Surface((w, h), pygame.SRCALPHA)
    tan = (215, 190, 150)
    pygame.draw.ellipse(s, (245, 245, 250), (0, 8, 10, 16))      # крылья
    pygame.draw.ellipse(s, (245, 245, 250), (26, 8, 10, 16))
    pygame.draw.ellipse(s, (205, 180, 145), (0, 8, 10, 16), 1)
    pygame.draw.ellipse(s, (205, 180, 145), (26, 8, 10, 16), 1)
    pygame.draw.ellipse(s, tan, (8, 4, 20, 24))                  # голова
    pygame.draw.ellipse(s, (90, 70, 55), (9, 3, 8, 9))           # уши
    pygame.draw.ellipse(s, (90, 70, 55), (19, 3, 8, 9))
    pygame.draw.ellipse(s, (60, 50, 45), (12, 14, 12, 9))        # морда (складки)
    pygame.draw.circle(s, (255, 255, 255), (14, 12), 3)          # глаза
    pygame.draw.circle(s, (255, 255, 255), (22, 12), 3)
    pygame.draw.circle(s, (25, 25, 25), (15, 12), 2)
    pygame.draw.circle(s, (25, 25, 25), (23, 12), 2)
    pygame.draw.circle(s, (30, 25, 25), (18, 18), 2)             # нос
    return s


def make_cheese_texture():
    """Сырный блок-ступень (уровень 11-12): жёлтый сыр с дырками."""
    s = pygame.Surface((TILE, TILE))
    s.fill((242, 200, 70))
    pygame.draw.rect(s, (252, 222, 110), (0, 0, TILE, 8))         # светлая корочка сверху
    rng = random.Random(7)
    for _ in range(6):
        x, y = rng.randint(5, TILE - 9), rng.randint(11, TILE - 8)
        r = rng.randint(3, 6)
        pygame.draw.circle(s, (214, 168, 44), (x, y), r)         # дырка
        pygame.draw.circle(s, (188, 146, 34), (x, y), r, 1)
    pygame.draw.rect(s, (205, 160, 40), (0, 0, TILE, TILE), 1)
    return s


def make_mouse_white_texture():
    """Заглушка белой (быстрой) мыши. Заменится на assets/mouse_white.png. Смотрит влево."""
    w, h = 34, 24
    s = pygame.Surface((w, h), pygame.SRCALPHA)
    body, ear, out = (246, 246, 250), (255, 200, 212), (178, 178, 192)
    pygame.draw.line(s, out, (31, 16), (24, 14), 2)              # хвост справа
    pygame.draw.circle(s, ear, (16, 7), 6)                      # уши
    pygame.draw.circle(s, ear, (8, 9), 5)
    pygame.draw.circle(s, out, (16, 7), 6, 1)
    pygame.draw.ellipse(s, body, (4, 6, 23, 16))                # тело
    pygame.draw.ellipse(s, out, (4, 6, 23, 16), 1)
    pygame.draw.circle(s, (35, 35, 40), (8, 13), 2)             # глаз слева
    pygame.draw.circle(s, (255, 150, 170), (3, 16), 2)          # нос
    pygame.draw.line(s, out, (3, 16), (0, 13), 1)               # усы
    pygame.draw.line(s, out, (3, 18), (0, 20), 1)
    return s


def make_mouse_gray_texture():
    """Заглушка серой (толстой, 2 HP) мыши. Заменится на assets/mouse_gray.png. Смотрит влево."""
    w, h = 42, 30
    s = pygame.Surface((w, h), pygame.SRCALPHA)
    body, ear, out = (150, 152, 162), (190, 165, 170), (95, 97, 108)
    pygame.draw.line(s, out, (39, 21), (30, 18), 3)             # толстый хвост
    pygame.draw.circle(s, ear, (19, 8), 8)                      # крупные уши
    pygame.draw.circle(s, ear, (9, 10), 7)
    pygame.draw.circle(s, out, (19, 8), 8, 1)
    pygame.draw.ellipse(s, body, (3, 7, 31, 21))               # пухлое тело
    pygame.draw.ellipse(s, out, (3, 7, 31, 21), 2)
    pygame.draw.circle(s, (30, 30, 35), (10, 16), 2)           # глаз
    pygame.draw.circle(s, (240, 130, 150), (3, 20), 3)         # нос
    pygame.draw.line(s, out, (3, 19), (-1, 15), 1)             # усы
    pygame.draw.line(s, out, (3, 22), (-1, 25), 1)
    return s


def make_unicorn_texture():
    """Заглушка радужного единорога (заменится на assets/unicorn.png). Смотрит влево."""
    w, h = 46, 38
    s = pygame.Surface((w, h), pygame.SRCALPHA)
    white, out = (250, 250, 255), (203, 198, 220)
    rainbow = [(255, 90, 90), (255, 175, 65), (255, 235, 85),
               (105, 215, 130), (85, 175, 255), (175, 115, 235)]
    for lx in (16, 24, 32):                                      # ноги
        pygame.draw.line(s, out, (lx, 26), (lx, 35), 3)
    for i, c in enumerate(rainbow):                             # хвост радужный (справа)
        pygame.draw.line(s, c, (40, 16 + i * 2), (45, 11 + i * 3), 2)
    pygame.draw.ellipse(s, white, (12, 14, 30, 16))            # тело
    pygame.draw.ellipse(s, out, (12, 14, 30, 16), 1)
    pygame.draw.polygon(s, white, [(9, 28), (17, 15), (23, 17), (18, 30)])   # шея
    pygame.draw.ellipse(s, white, (3, 9, 16, 15))              # голова
    pygame.draw.ellipse(s, out, (3, 9, 16, 15), 1)
    pygame.draw.polygon(s, (255, 215, 90), [(7, 9), (4, 0), (12, 7)])        # рог
    pygame.draw.polygon(s, (220, 170, 40), [(7, 9), (4, 0), (12, 7)], 1)
    for i, c in enumerate(rainbow):                            # грива вдоль шеи
        pygame.draw.line(s, c, (12 + i, 8 + i), (19 + i, 18 + i), 2)
    pygame.draw.polygon(s, white, [(13, 9), (16, 3), (18, 10)])             # ухо
    pygame.draw.circle(s, (45, 30, 55), (9, 15), 2)            # глаз
    return s


MAKERS = {
    "gunner": make_gunner_texture, "bomber": make_bomber_texture,
    "fish": make_fish_texture, "emedusa": make_emedusa_texture,
    "boss": make_boss_texture, "chick": make_chick_texture, "pug": make_pug_texture,
    "mouse_white": make_mouse_white_texture, "mouse_gray": make_mouse_gray_texture,
    "unicorn": make_unicorn_texture,
}


def load_sprite(name, maker=None):
    try:
        img = pygame.image.load(f"assets/{name}.png").convert_alpha()
    except (pygame.error, FileNotFoundError):
        if maker:
            return maker()
        s = pygame.Surface((28, 32), pygame.SRCALPHA)
        s.fill((200, 80, 200))
        return s
    img = img.subsurface(img.get_bounding_rect(min_alpha=1)).copy()
    w, h = img.get_size()
    th = SPRITES[name]
    return pygame.transform.smoothscale(img, (max(1, round(w * th / h)), th))


def make_shadow_texture():
    """Мягкая тень-эллипс (рисуется один раз, масштабируется под объект)."""
    w, h = 100, 28
    s = pygame.Surface((w, h), pygame.SRCALPHA)
    layers = 8
    for i in range(layers):
        t = (i + 1) / layers
        ew, eh = int(w * t), int(h * t)
        pygame.draw.ellipse(s, (18, 22, 40, int(64 * t)),
                            (w // 2 - ew // 2, h // 2 - eh // 2, ew, eh))
    return s


def make_vignette():
    """Затемнение по краям экрана (один blit поверх кадра)."""
    w, h = WIDTH + 2 * SHAKE_MARGIN, HEIGHT + 2 * SHAKE_MARGIN
    s = pygame.Surface((w, h), pygame.SRCALPHA)
    depth = 130
    for i in range(depth):
        a = int(58 * (1 - i / depth) ** 2)
        if a > 0:
            pygame.draw.rect(s, (0, 0, 0, a), (i, i, w - 2 * i, h - 2 * i), 1)
    return s


def make_gradient(top, bot, h=None):
    """Вертикальный градиент шириной с буфер (кэш фона)."""
    w = WIDTH + 2 * SHAKE_MARGIN
    h = h or (HEIGHT + 2 * SHAKE_MARGIN)
    s = pygame.Surface((w, h))
    for y in range(h):
        t = y / max(1, h - 1)
        s.fill(tuple(int(top[k] + (bot[k] - top[k]) * t) for k in range(3)), (0, y, w, 1))
    return s


def make_glow(color, r):
    """Мягкое радиальное свечение (кэш, blit под источники света)."""
    s = pygame.Surface((r * 2, r * 2), pygame.SRCALPHA)
    for i in range(r, 0, -1):
        pygame.draw.circle(s, color + (int(70 * (1 - i / r)),), (r, r), i)
    return s


FONT_PATH = "assets/fonts/Rubik.ttf"        # современный шрифт с кириллицей (OFL), везём в веб


def _load_font(size):
    """Rubik (жирный) из assets; если файла нет — системный запасной."""
    try:
        f = pygame.font.Font(FONT_PATH, size)
    except (FileNotFoundError, OSError, pygame.error):
        f = pygame.font.SysFont("segoeui,calibri,verdana,arial", size)
    f.set_bold(True)
    return f


def build_assets():
    assets = {
        "ground": make_ground_texture(),
        "brick": make_brick_texture(),
        "softbrick": make_softbrick_texture(),
        "sand": make_sand_texture(),
        "rock": make_rock_texture(),
        "ice": make_ice_texture(),
        "cheese": make_cheese_texture(),
        "cloud": make_cloud_texture(),
        "shadow": make_shadow_texture(),
        "vignette": make_vignette(),
        "glow": make_glow((255, 225, 120), 22),
        "sky_grad": make_gradient((125, 192, 245), (200, 230, 250)),
        "font": _load_font(24),
        "big": _load_font(60),
        "small": _load_font(18),
    }
    for name in SPRITES:
        assets[name] = load_sprite(name, MAKERS.get(name))
    return assets


# =====================================================================
#  Звук: всё синтезируется кодом (как и графика) — без внешних файлов,
#  совместимо с вебом. Нет numpy/mixer — игра просто работает молча.
# =====================================================================

_SR = 44100
SOUNDS = {}
SOUND_ON = True


def play(name):
    if SOUND_ON and name in SOUNDS:
        SOUNDS[name].play()


def _env(n, attack=0.005, release=0.03):
    e = _np.ones(n)
    a = min(int(attack * _SR), n // 2)
    r = min(int(release * _SR), n // 2)
    if a > 0:
        e[:a] = _np.linspace(0, 1, a)
    if r > 0:
        e[-r:] = _np.linspace(1, 0, r)
    return e


def _note(freq, dur, wave="square", vol=0.5, sweep=None):
    n = max(1, int(dur * _SR))
    t = _np.linspace(0, dur, n, False)
    if sweep is not None:                                # глиссандо freq → sweep
        phase = 2 * _np.pi * _np.cumsum(_np.linspace(freq, sweep, n)) / _SR
    else:
        phase = 2 * _np.pi * freq * t
    if wave == "square":
        w = _np.sign(_np.sin(phase))
    elif wave == "saw":
        w = 2 * ((phase / (2 * _np.pi)) % 1.0) - 1
    elif wave == "noise":
        w = _np.random.uniform(-1, 1, n)
    else:
        w = _np.sin(phase)
    return w * _env(n) * vol


def _seq(parts):
    return _np.concatenate(parts) if parts else _np.zeros(1)


def _make(arr, vol=1.0):
    audio = (_np.clip(arr * vol, -1, 1) * 32767).astype(_np.int16)
    return pygame.sndarray.make_sound(_np.column_stack((audio, audio)).copy())


def _beam_wave():                                        # гудящий радужный луч с вибрато
    dur = 0.7
    n = int(dur * _SR)
    t = _np.linspace(0, dur, n, False)
    f = 320 + _np.sin(2 * _np.pi * 18 * t) * 40
    phase = 2 * _np.pi * _np.cumsum(f) / _SR
    w = _np.sign(_np.sin(phase)) * 0.5 + _np.sin(phase * 2) * 0.5
    return w * _env(n, 0.02, 0.1) * 0.4


def _music_loop():                                       # лёгкая чиптюн-петля I–V–vi–IV
    beat = 0.16
    chords = [(262, 330, 392), (196, 247, 392), (220, 262, 330), (175, 220, 262)]
    pat = [0, 1, 2, 1]
    mel, bass = [], []
    for ch in chords:
        for i in range(4):
            mel.append(_note(ch[pat[i]], beat, "square", 0.16))
            bass.append(_note(ch[0] / 2, beat, "saw", 0.10))
    m, b = _seq(mel), _seq(bass)
    k = min(len(m), len(b))
    return m[:k] + b[:k]


def build_sounds():
    if not _ensure_numpy() or pygame.mixer.get_init() is None:
        return
    try:
        SOUNDS.update({
            "jump":     _make(_note(320, 0.13, "square", 0.4, sweep=720)),
            "coin":     _make(_seq([_note(988, 0.06, "square", 0.4),
                                    _note(1319, 0.09, "square", 0.4)])),
            "stomp":    _make(_note(520, 0.12, "square", 0.45, sweep=150)),
            "hurt":     _make(_seq([_note(400, 0.05, "square", 0.4, sweep=300),
                                    _note(260, 0.22, "saw", 0.4, sweep=90)])),
            "pit":      _make(_note(820, 0.32, "sine", 0.4, sweep=110)),
            "powerup":  _make(_seq([_note(f, 0.06, "square", 0.4)
                                    for f in (523, 659, 784, 1047, 1319)])),
            "super":    _make(_seq([_note(f, 0.05, "square", 0.4)
                                    for f in (659, 880, 1047, 1319, 1568)])),
            "shoot":    _make(_note(700, 0.08, "square", 0.28, sweep=1150)),
            "brick":    _make(_note(1, 0.10, "noise", 0.35)),
            "boss_hit": _make(_seq([_note(180, 0.05, "noise", 0.4),
                                    _note(880, 0.10, "square", 0.4, sweep=400)])),
            "charge":   _make(_note(200, 0.5, "saw", 0.32, sweep=820)),
            "beam":     _make(_beam_wave()),
            "levelup":  _make(_seq([_note(f, 0.08, "square", 0.4)
                                    for f in (784, 1047, 1319)])),
            "win":      _make(_seq([_note(f, 0.12, "square", 0.45)
                                    for f in (523, 659, 784, 1047, 1319, 1047, 1319)])),
            "lose":     _make(_seq([_note(f, 0.18, "square", 0.4)
                                    for f in (392, 330, 262, 196)])),
            "music":    _make(_music_loop()),
        })
    except (pygame.error, ValueError):
        SOUNDS.clear()


CLOUDS = [(120, 60), (560, 110), (980, 50), (1480, 95), (1980, 70),
          (2600, 100), (3100, 60), (3500, 100)]
HILLS = [(260, 90), (900, 130), (1600, 100), (2300, 140), (3000, 90), (3600, 120)]

# Подводный декор (мировые X)
CORALS = [(200, 0), (470, 1), (820, 2), (1150, 0), (1700, 1),
          (2050, 2), (2500, 0), (2900, 1), (3300, 2)]
SEAWEED = [(120, 70), (380, 95), (680, 60), (1050, 85), (1400, 100),
           (1950, 72), (2300, 92), (2750, 64), (3150, 88), (3450, 76)]
BUBBLE_COLS = [150, 520, 900, 1320, 1780, 2200, 2680, 3150, 3500]
CORAL_COLORS = [(255, 120, 140), (255, 170, 90), (180, 130, 230)]


# =====================================================================
#  Движущаяся платформа
# =====================================================================

class MovingPlatform:
    def __init__(self, x, y, w, h, axis, lo, hi, speed, visual="wood"):
        self.rect = pygame.Rect(x, y, w, h)
        self.axis = axis
        self.visual = visual
        self.lo, self.hi = lo, hi
        self.speed = speed
        self.dir = 1
        self.fx, self.fy = float(x), float(y)
        self.dx = self.dy = 0.0

    def update(self):
        if self.axis == "x":
            n = self.fx + self.speed * self.dir
            if n <= self.lo:
                n, self.dir = self.lo, 1
            elif n >= self.hi:
                n, self.dir = self.hi, -1
            self.dx, self.dy = n - self.fx, 0.0
            self.fx = n
            self.rect.x = round(n)
        else:
            n = self.fy + self.speed * self.dir
            if n <= self.lo:
                n, self.dir = self.lo, 1
            elif n >= self.hi:
                n, self.dir = self.hi, -1
            self.dx, self.dy = 0.0, n - self.fy
            self.fy = n
            self.rect.y = round(n)


# =====================================================================
#  Лопасть крутящегося колеса (уровень 14): платформа на ободе.
#  Совместима с интерфейсом mover (.rect/.dx/.visual/.update) — едет в self.movers.
# =====================================================================

class WheelSpoke:
    def __init__(self, cx, cy, radius, angle0, speed, visual="spoke"):
        self.cx, self.cy = cx, cy
        self.radius = radius
        self.angle = angle0
        self.speed = speed
        self.visual = visual
        self.rect = pygame.Rect(0, 0, SPOKE_W, SPOKE_H)
        self.dx = self.dy = 0.0
        self._place()

    def _place(self):
        self.rect.center = (round(self.cx + math.cos(self.angle) * self.radius),
                            round(self.cy + math.sin(self.angle) * self.radius))

    def update(self):
        px, py = self.rect.centerx, self.rect.centery
        self.angle += self.speed
        self._place()
        self.dx = self.rect.centerx - px       # для переноса игрока (как у MovingPlatform)
        self.dy = self.rect.centery - py


# =====================================================================
#  Враг: поведение по kind, внешность по skin
# =====================================================================

class Enemy:
    def __init__(self, kind, skin, x, y, **kw):
        self.kind = kind
        self.skin = skin
        self.alive = True
        self.dying = False
        self.death_timer = 0
        self.stompable = kind not in ("fish", "emedusa")   # водных не стомпнуть
        self.hp = kw.get("hp", 1)          # >1 — нужно стомпнуть несколько раз (серая мышь)
        self.flash = 0                     # кадры подсветки после непробивающего удара
        if kind == "walker":
            self.rect = pygame.Rect(x, y, 34, 32)
            self.dir = -1
            self.min_x, self.max_x = kw["min_x"], kw["max_x"]
            self.speed = kw.get("speed", WALK_SPEED)
            self.fx = float(x)
        elif kind in ("flyer", "bomber", "emedusa"):
            self.rect = pygame.Rect(x, y, 36 if kind != "emedusa" else 30, 28 if kind != "emedusa" else 34)
            self.dir = -1
            self.min_x, self.max_x = kw["min_x"], kw["max_x"]
            self.home_y = y
            self.amp = kw.get("amp", 32)
            self.phase = 0.0
            self.fx = float(x)
            if kind == "bomber":
                self.shoot_timer = kw.get("shoot_timer", SHOOT_INTERVAL + 45)
        elif kind == "jumper":
            self.rect = pygame.Rect(x, y, 32, 32)
            self.floor = kw["floor"]
            self.vy = 0.0
            self.fy = float(y)
            self.on_ground = True
            self.timer = JUMP_ENEMY_WAIT
        elif kind == "gunner":
            self.rect = pygame.Rect(x, y, 32, 34)
            self.shoot_timer = kw.get("shoot_timer", SHOOT_INTERVAL)
        elif kind == "fish":
            self.rect = pygame.Rect(x, y, 40, 24)
            self.dir = -1
            self.min_x, self.max_x = kw["min_x"], kw["max_x"]
            self.fx = float(x)
        elif kind == "goose":
            self.rect = pygame.Rect(x, y, 34, 30)
            self.cloud = kw.get("cloud")      # облако-платформа, на которой сидит гусь
            self.dir = -1

    def kill(self):
        self.alive = False
        self.dying = True
        self.death_timer = DEATH_FRAMES

    def hit_stomp(self):
        """Урон от стомпа/выстрела. True — враг погиб; False — ранен, но жив (толстая мышь)."""
        self.hp -= 1
        if self.hp <= 0:
            self.kill()
            return True
        self.flash = 16
        return False

    def _patrol(self, speed):
        self.fx += speed * self.dir
        self.rect.x = round(self.fx)
        if self.rect.left <= self.min_x:
            self.rect.left = self.min_x
            self.fx = float(self.rect.x)
            self.dir = 1
        elif self.rect.right >= self.max_x:
            self.rect.right = self.max_x
            self.fx = float(self.rect.x)
            self.dir = -1

    def update(self):
        if self.flash > 0:
            self.flash -= 1
        if self.dying:
            self.death_timer -= 1
            if self.death_timer <= 0:
                self.dying = False
            return
        if not self.alive:
            return
        if self.kind == "walker":
            self._patrol(self.speed)
        elif self.kind in ("flyer", "bomber", "emedusa"):
            self.phase += FLY_STEP
            self.rect.y = round(self.home_y + math.sin(self.phase) * self.amp)
            self._patrol(FLY_SPEED if self.kind != "emedusa" else 0.8)
        elif self.kind == "fish":
            self._patrol(FISH_SPEED)
        elif self.kind == "goose":
            if self.cloud is not None:               # сидит на облаке и едет вместе с ним
                self.rect.midbottom = (self.cloud.rect.centerx, self.cloud.rect.top)
                self.dir = -1 if self.cloud.dx < 0 else 1
        elif self.kind == "jumper":
            self.vy = min(self.vy + GRAVITY, MAX_FALL)
            self.fy += self.vy
            self.rect.y = round(self.fy)
            if self.rect.bottom >= self.floor:
                self.rect.bottom = self.floor
                self.fy = float(self.rect.y)
                self.vy = 0.0
                self.on_ground = True
            if self.on_ground:
                self.timer -= 1
                if self.timer <= 0:
                    self.vy = -JUMP_ENEMY_SPEED
                    self.on_ground = False
                    self.timer = JUMP_ENEMY_WAIT
        # gunner стоит на месте


# =====================================================================
#  Босс (уровень 5)
# =====================================================================

class Boss:
    def __init__(self, x, y):
        self.rect = pygame.Rect(x, y, 84, 40)
        self.fx, self.fy = float(x), float(y)
        self.hp = BOSS_HP
        self.vy = 0.0
        self.dir = 1
        self.phase = "move"          # move | telegraph | slam | stunned
        self.timer = BOSS_MOVE_TIME
        self.invuln = 0
        self.alive = True
        self.dying = False
        self.death_timer = 70
        self.anim = 0

    def hit(self):
        if self.invuln > 0 or not self.alive:
            return False
        self.hp -= 1
        self.invuln = BOSS_INVULN
        if self.hp <= 0:
            self.hp = 0
            self.alive = False
            self.dying = True
            self.phase = "dead"
        return True

    def update(self, player, floor, arena_w):
        self.anim += 1
        if self.dying:
            self.death_timer -= 1
            self.fy += 1.6                       # оседает на пол
            self.rect.y = round(self.fy)
            if self.death_timer <= 0:
                self.dying = False               # анимация гибели закончилась
            return
        if self.invuln > 0:
            self.invuln -= 1

        if self.phase == "move":
            self.fy += (BOSS_HOVER_Y - self.fy) * 0.08
            if player.centerx > self.rect.centerx + 8:
                self.dir = 1
            elif player.centerx < self.rect.centerx - 8:
                self.dir = -1
            self.fx += BOSS_MOVE_SPEED * self.dir
            self.timer -= 1
            if self.timer <= 0:
                self.phase, self.timer = "telegraph", BOSS_TELE_TIME
        elif self.phase == "telegraph":
            self.fy += (BOSS_HOVER_Y - self.fy) * 0.1
            target = player.centerx - self.rect.width / 2
            self.fx += (target - self.fx) * 0.18
            self.timer -= 1
            if self.timer <= 0:
                self.phase, self.vy = "slam", 0.0
        elif self.phase == "slam":
            self.vy = min(self.vy + BOSS_SLAM_GRAV, BOSS_SLAM_MAX)
            self.fy += self.vy
            if self.fy + self.rect.height >= floor:
                self.fy = floor - self.rect.height
                self.phase, self.timer = "stunned", BOSS_STUN_TIME
        elif self.phase == "stunned":
            self.timer -= 1
            if self.timer <= 0:
                self.phase, self.timer = "move", BOSS_MOVE_TIME

        self.fx = max(0, min(self.fx, arena_w - self.rect.width))
        self.rect.x = round(self.fx)
        self.rect.y = round(self.fy)


# =====================================================================
#  Босс-муравей (уровень 10): бегает по полу → плюётся кислотой → уязвим
# =====================================================================

class AntBoss:
    kind = "ant"

    def __init__(self, x, floor_y):
        self.rect = pygame.Rect(x, floor_y - ANT_H, ANT_W, ANT_H)
        self.fx = float(x)
        self.hp = BOSS_HP
        self.dir = -1
        self.phase = "run"           # run | aim | stunned (уязвим) | dead
        self.timer = ANT_RUN_TIME
        self.invuln = 0
        self.alive = True
        self.dying = False
        self.death_timer = 80
        self.anim = 0
        self.head_drop = 0.0         # 0 — голова поднята, 1 — опущена (уязвим)
        self.new_spits = []          # капли, заспавненные в этом кадре (забирает игра)
        self.no_go = []              # X-зоны под низкими кирпичами: там не останавливается

    def hit(self):
        if self.invuln > 0 or not self.alive:
            return False
        self.hp -= 1
        self.invuln = ANT_INVULN
        if self.hp <= 0:
            self.hp = 0
            self.alive = False
            self.dying = True
            self.phase = "dead"
        else:
            self.phase, self.timer = "run", ANT_RUN_TIME   # очухался и снова побежал
            self.head_drop = 0.0
        return True

    def _face(self, player):
        if player.centerx > self.rect.centerx + 6:
            self.dir = 1
        elif player.centerx < self.rect.centerx - 6:
            self.dir = -1

    def _under_overhang(self):                             # центр под низким кирпичом?
        cx = self.fx + self.rect.width / 2
        return any(zL < cx < zR for zL, zR in self.no_go)

    def _exit_dir(self):                                   # в какую сторону ближе выйти из-под кирпича
        cx = self.fx + self.rect.width / 2
        for zL, zR in self.no_go:
            if zL < cx < zR:
                return -1 if (cx - zL) < (zR - cx) else 1
        return self.dir

    def _spit_volley(self):
        mx = self.rect.centerx + self.dir * (self.rect.width // 2 - 8)
        my = self.rect.top + 10
        for k in range(ANT_SPIT_COUNT):                    # веер: разная дальность
            vx = self.dir * (SPIT_SPEED - k * 1.5)
            vy = -(7.4 - k * 1.6)
            self.new_spits.append((mx, my, vx, vy))

    def update(self, player, floor, arena_w):
        self.anim += 1
        self.new_spits = []
        if self.dying:
            self.death_timer -= 1
            if self.death_timer <= 0:
                self.dying = False               # анимация гибели закончилась
            return
        if self.invuln > 0:
            self.invuln -= 1

        if self.phase == "run":
            self.head_drop += (0.0 - self.head_drop) * 0.2
            self.timer -= 1
            if self.timer > 0:
                self._face(player)                       # преследует игрока
                self.fx += ANT_RUN_SPEED * self.dir
            elif self._under_overhang():                 # пора плеваться, но он под кирпичом —
                self.dir = self._exit_dir()              #   сперва выходит на открытое место
                self.fx += ANT_RUN_SPEED * self.dir
            else:
                self.phase, self.timer = "aim", ANT_AIM_TIME
        elif self.phase == "aim":
            self.head_drop += (0.0 - self.head_drop) * 0.2
            self._face(player)                   # доворачивается к игроку перед плевком
            self.timer -= 1
            if self.timer <= 0:
                self._spit_volley()
                self.phase, self.timer = "stunned", ANT_VULN_TIME
        elif self.phase == "stunned":
            self.head_drop += (1.0 - self.head_drop) * 0.15
            self.timer -= 1
            if self.timer <= 0:
                self.phase, self.timer = "run", ANT_RUN_TIME

        self.fx = max(0, min(self.fx, arena_w - self.rect.width))
        self.rect.x = round(self.fx)
        self.rect.bottom = floor


# =====================================================================
#  Босс-единорог (уровень 15, финал): ходит → заряд рога 0.5 c →
#  радужный луч во всю ширину (сквозь платформы) → уязвим для прыжка на голову
# =====================================================================

class UnicornBoss:
    kind = "unicorn"

    def __init__(self, x, floor_y):
        self.rect = pygame.Rect(x, floor_y - UNI_H, UNI_W, UNI_H)
        self.fx = float(x)
        self.hp = UNI_HP
        self.max_hp = UNI_HP
        self.dir = -1
        self.phase = "move"          # move | charge | beam | stunned (уязвим) | dead
        self.timer = UNI_MOVE_TIME
        self.invuln = 0
        self.alive = True
        self.dying = False
        self.death_timer = 90
        self.anim = 0
        self.head_drop = 0.0         # 0 — голова поднята, 1 — опущена (уязвим)
        self.glow = 0.0              # заряд рога 0..1 (для отрисовки charge/beam)
        self.beam_on = False         # активен ли разящий луч
        self.aim_angle = 0.0         # прицел: в charge следит за игроком
        self.beam_angle = 0.0        # зафиксированный угол луча (в beam)
        self.beam_origin = (float(self.rect.centerx), float(self.rect.top))

    def horn_pos(self):              # кончик рога в мировых координатах — исток луча
        return (self.rect.centerx + self.dir * (UNI_W * 0.42), self.rect.top - 6)

    def hit(self):
        if self.invuln > 0 or not self.alive:
            return False
        self.hp -= 1
        self.invuln = UNI_INVULN
        if self.hp <= 0:
            self.hp = 0
            self.alive = False
            self.dying = True
            self.phase = "dead"
            self.beam_on = False
        else:
            self.phase, self.timer = "hurt", UNI_HURT_TIME   # отшатнулся — стоит ~0.7 c
        return True

    def _face(self, player):
        if player.centerx > self.rect.centerx + 6:
            self.dir = 1
        elif player.centerx < self.rect.centerx - 6:
            self.dir = -1

    def update(self, player, floor, arena_w):
        self.anim += 1
        if self.dying:
            self.death_timer -= 1
            if self.death_timer <= 0:
                self.dying = False               # анимация гибели закончилась
            return
        if self.invuln > 0:
            self.invuln -= 1

        if self.phase == "move":                 # преследует игрока по полу
            self.head_drop += (0.0 - self.head_drop) * 0.2
            self.glow += (0.0 - self.glow) * 0.2
            self._face(player)
            self.fx += UNI_MOVE_SPEED * self.dir
            self.timer -= 1
            if self.timer <= 0:                  # навёлся на игрока ОДИН раз и зафиксировал прицел
                self._face(player)
                hx, hy = self.horn_pos()
                self.aim_angle = math.atan2(player.centery - hy, player.centerx - hx)
                self.beam_origin = (hx, hy)
                self.phase, self.timer = "charge", UNI_CHARGE_TIME
                play("charge")
        elif self.phase == "charge":             # 0.5 c телеграф: прицел зафиксирован, НЕ следит
            self.glow = 1.0 - max(0.0, self.timer / UNI_CHARGE_TIME)
            self.timer -= 1
            if self.timer <= 0:
                self.phase, self.timer = "beam", UNI_BEAM_TIME
                self.beam_on = True
                self.beam_angle = self.aim_angle     # стреляем по зафиксированному прицелу
                play("beam")
        elif self.phase == "beam":               # луч во всю ширину экрана
            self.glow = 1.0
            self.timer -= 1
            if self.timer <= 0:
                self.beam_on = False
                self.phase, self.timer = "stunned", UNI_VULN_TIME
        elif self.phase == "stunned":            # уязвим: голова опущена — бей прыжком
            self.head_drop += (1.0 - self.head_drop) * 0.15
            self.glow += (0.0 - self.glow) * 0.2
            self.timer -= 1
            if self.timer <= 0:
                self.phase, self.timer = "move", UNI_MOVE_TIME
        elif self.phase == "hurt":               # отшатнулся после удара — стоит на месте ~0.7 c
            self.head_drop += (0.0 - self.head_drop) * 0.15
            self.glow += (0.0 - self.glow) * 0.2
            self.timer -= 1
            if self.timer <= 0:
                self.phase, self.timer = "move", UNI_MOVE_TIME

        lo = UNI_EDGE_MARGIN                      # держится центра — не лезет на боковые уступы
        hi = arena_w - UNI_EDGE_MARGIN - self.rect.width
        self.fx = max(lo, min(self.fx, hi))
        self.rect.x = round(self.fx)
        self.rect.bottom = floor


# =====================================================================
#  Цыплёнок-усилитель: убегает от игрока, при поимке даёт супер-форму
# =====================================================================

class Chick:
    def __init__(self, x, y):
        self.rect = pygame.Rect(x, y, 22, 22)
        self.fx, self.fy = float(x), float(y)
        self.vy = 0.0
        self.alive = True
        self.anim = 0
        self.facing = 1

    def update(self, player, solids, level_w):
        self.anim += 1
        flee = 1 if self.rect.centerx >= player.centerx else -1
        self.facing = flee
        self.fx += CHICK_SPEED * flee
        self.rect.x = round(self.fx)
        for r, k in solids:
            if self.rect.colliderect(r):
                if flee > 0:
                    self.rect.right = r.left
                else:
                    self.rect.left = r.right
        self.rect.x = max(0, min(self.rect.x, level_w - self.rect.width))
        self.fx = float(self.rect.x)
        self.vy = min(self.vy + GRAVITY, MAX_FALL)
        self.fy += self.vy
        self.rect.y = round(self.fy)
        for r, k in solids:
            if self.rect.colliderect(r):
                if self.vy > 0:
                    self.rect.bottom = r.top
                    self.vy = 0
                elif self.vy < 0:
                    self.rect.top = r.bottom
                    self.vy = 0
                self.fy = float(self.rect.y)


# =====================================================================
#  Падающее дерево (уровень 7): шатается → падает (урон) → мост-платформа
# =====================================================================

class FallingTree:
    def __init__(self, base_x, ground_y, height, direction, crown_r=34):
        self.base_x = base_x
        self.ground_y = ground_y
        self.height = height
        self.direction = direction      # -1 падает влево, +1 вправо
        self.crown_r = crown_r
        self.phase = "stand"            # stand | shake | fall | fallen
        self.timer = 0
        self.angle = 0.0                # 0 вертикально … 90 лежит
        self.anim = 0
        if direction > 0:
            self.fallen_rect = pygame.Rect(base_x, ground_y - TREE_TRUNK_W, height, TREE_TRUNK_W)
        else:
            self.fallen_rect = pygame.Rect(base_x - height, ground_y - TREE_TRUNK_W, height, TREE_TRUNK_W)

    def trigger(self):
        if self.phase == "stand":
            self.phase = "shake"
            self.timer = TREE_SHAKE_TIME

    def hit_rect(self):
        """Зона, накрытая стволом в текущий момент падения."""
        reach = int(self.height * math.sin(math.radians(self.angle)))
        if self.direction > 0:
            return pygame.Rect(self.base_x, self.ground_y - TREE_TRUNK_W, reach, TREE_TRUNK_W)
        return pygame.Rect(self.base_x - reach, self.ground_y - TREE_TRUNK_W, reach, TREE_TRUNK_W)

    def draw_angle(self):
        """Угол наклона для отрисовки (с дрожанием при шатании), со знаком направления."""
        wobble = math.sin(self.anim * 0.6) * 5 if self.phase == "shake" else 0.0
        return (self.angle + wobble) * self.direction

    def update(self):
        self.anim += 1
        if self.phase == "shake":
            self.timer -= 1
            if self.timer <= 0:
                self.phase = "fall"
        elif self.phase == "fall":
            self.angle = min(90.0, self.angle + TREE_FALL_SPEED)
            if self.angle >= 90.0:
                self.phase = "fallen"


# =====================================================================
#  Лазер + кот (уровень 12): точка гоняется за игроком, кот — за точкой;
#  поймала точка → через секунду кот прыгает в это место, надо увернуться
# =====================================================================

class LaserCat:
    def __init__(self, x, floor_y, level_w, speed_mult=1.0):
        self.floor = floor_y
        self.level_w = level_w
        self.sm = speed_mult                         # общий множитель скорости (ур.13 = 2.0)
        self.aim_norm = max(12, round(CAT_AIM_TIME / speed_mult))   # время наведения до прыжка
        self.aim_fast = max(8, round(CAT_BURST_AIM / speed_mult))   # то же в рывке
        self.leap_vx_max = CAT_LEAP_VX_MAX * speed_mult             # горизонталь прыжка
        self.dot_x = float(x)
        self.dot_y = float(floor_y - 30)
        self.phase = "chase"             # chase | aim | leap | recover
        self.timer = 0
        self.target_x = float(x)
        self.target_y = float(floor_y)
        self.cat = pygame.Rect(int(x), floor_y - CAT_H, CAT_W, CAT_H)
        self.cfx, self.cfy = float(self.cat.x), float(self.cat.y)
        self.cvx = self.cvy = 0.0
        self.facing = -1
        self.anim = 0
        self.frenzy = False                          # рывок: точка летит быстро, прыжок раньше
        self.burst_cd = random.uniform(CAT_BURST_MIN, CAT_BURST_MAX) * FPS

    def _approach(self, tx, ty, sp):                 # точка плавно ползёт к (tx, ty)
        dx, dy = tx - self.dot_x, ty - self.dot_y
        dist = math.hypot(dx, dy)
        if dist <= sp:
            self.dot_x, self.dot_y = tx, ty
        else:
            self.dot_x += dx / dist * sp
            self.dot_y += dy / dist * sp

    def _run_to(self, tx):                            # кот бежит по полу за точкой
        sp = CAT_RUN_SPEED * self.sm * (CAT_BURST_RUN if self.frenzy else 1.0)
        if tx > self.cat.centerx + 4:
            self.cfx += sp
            self.facing = 1
        elif tx < self.cat.centerx - 4:
            self.cfx -= sp
            self.facing = -1
        self.cfx = max(0, min(self.cfx, self.level_w - CAT_W))
        self.cat.x = round(self.cfx)
        self.cat.bottom = self.floor
        self.cfy = float(self.cat.y)

    def update(self, player):
        self.anim += 1
        if self.phase == "chase":
            if not self.frenzy:                       # копим до следующего рывка
                self.burst_cd -= 1
                if self.burst_cd <= 0:
                    self.frenzy = True
            sp = LASER_SPEED * self.sm * (CAT_BURST_SPEED if self.frenzy else 1.0)
            self._approach(player.centerx, player.centery, sp)
            self._run_to(self.dot_x)
            if math.hypot(self.dot_x - player.centerx, self.dot_y - player.centery) < LASER_LOCK:
                self.phase = "aim"
                self.timer = self.aim_fast if self.frenzy else self.aim_norm
                self.target_x, self.target_y = float(player.centerx), float(player.bottom)
        elif self.phase == "aim":                     # точка зафиксирована, кот подбирается
            self._approach(self.target_x, self.target_y - 4, LASER_SPEED * self.sm * 1.6)
            self._run_to(self.target_x)
            self.timer -= 1
            if self.timer <= 0:                       # прыжок в зафиксированную точку
                self.phase = "leap"
                self.facing = 1 if self.target_x >= self.cat.centerx else -1
                self.cvy = CAT_LEAP_VY
                self.cvx = max(-self.leap_vx_max, min(self.leap_vx_max,
                                                      (self.target_x - self.cat.centerx) / 18 * self.sm))
        elif self.phase == "leap":
            self.cvy = min(self.cvy + CAT_GRAV, MAX_FALL)
            self.cfx = max(0, min(self.cfx + self.cvx, self.level_w - CAT_W))
            self.cfy += self.cvy
            self.cat.x, self.cat.y = round(self.cfx), round(self.cfy)
            self.dot_x, self.dot_y = self.target_x, self.target_y - 4
            if self.cat.bottom >= self.floor:
                self.cat.bottom = self.floor
                self.cfx, self.cfy = float(self.cat.x), float(self.cat.y)
                self.phase, self.timer = "recover", CAT_RECOVER_TIME
                if self.frenzy:                       # рывок закончился — ждём до следующего
                    self.frenzy = False
                    self.burst_cd = random.uniform(CAT_BURST_MIN, CAT_BURST_MAX) * FPS
        elif self.phase == "recover":                 # отдышался — точка снова ищет игрока
            self._approach(player.centerx, player.centery, LASER_SPEED * 0.5)
            self.timer -= 1
            if self.timer <= 0:
                self.phase = "chase"


# =====================================================================
#  Сохранение: localStorage в браузере (pygbag), файл на десктопе
# =====================================================================

def _storage_write(text):
    if IS_WEB:
        try:
            import platform as _pf
            _pf.window.localStorage.setItem(SAVE_KEY, text)
            return
        except Exception:
            pass
    try:
        with open(SAVE_FILE, "w", encoding="utf-8") as f:
            f.write(text)
    except OSError:
        pass


def _storage_read():
    if IS_WEB:
        try:
            import platform as _pf
            return _pf.window.localStorage.getItem(SAVE_KEY)
        except Exception:
            pass
    try:
        with open(SAVE_FILE, encoding="utf-8") as f:
            return f.read()
    except OSError:
        return None


def _storage_clear():
    if IS_WEB:
        try:
            import platform as _pf
            _pf.window.localStorage.removeItem(SAVE_KEY)
            return
        except Exception:
            pass
    try:
        os.remove(SAVE_FILE)
    except OSError:
        pass


# =====================================================================
#  Игровая логика
# =====================================================================

class Game:
    def __init__(self):
        self.anim = 0
        self.test_mode = False          # 7 сердец для тестирования (клавиша T)
        self.state = "menu"             # стартуем в главном меню
        self.menu_index = 0
        self.bonus_hearts = 0           # +1 макс. сердце за каждого побеждённого босса
        self.level_banner_timer = 0     # «УРОВЕНЬ N» при заходе на уровень
        self.touch_ui = True            # показывать экранные сенсорные кнопки

    @property
    def max_lives(self):
        return (7 if self.test_mode else 3) + getattr(self, "bonus_hearts", 0)

    # --- меню и сохранение ---
    def menu_options(self):
        opts = []
        if self.has_save():
            opts.append("Продолжить")
        opts += ["Новая игра", "Настройки", "Выйти"]
        return opts

    def settings_options(self):
        return [
            "Тест-режим (7 сердец): " + ("Вкл" if self.test_mode else "Выкл"),
            "Сенсорные кнопки: " + ("Вкл" if self.touch_ui else "Выкл"),
            "Сбросить сохранение" if self.has_save() else "Сохранения нет",
            "Назад",
        ]

    def lose_options(self):
        opts = ["Начать с начала"]
        if self.has_save():
            opts.append("Загрузить сохранение")
        return opts

    def select_option(self, choice):
        """Обрабатывает выбор пункта меню/настроек/экрана гибели. True — выйти из игры."""
        if choice in ("Продолжить", "Загрузить сохранение"):
            self.continue_game()
        elif choice in ("Новая игра", "Начать с начала"):
            self.new_game()
        elif choice == "Настройки":
            self.state = "settings"
            self.menu_index = 0
        elif choice == "Назад":
            self.state = "menu"
            self.menu_index = 0
        elif choice == "Выйти":
            return True
        elif choice.startswith("Тест-режим"):
            self.test_mode = not self.test_mode
        elif choice.startswith("Сенсорные"):
            self.touch_ui = not self.touch_ui
        elif choice.startswith("Сбросить"):
            self.reset_save()
        return False

    def has_save(self):
        return _storage_read() is not None

    def reset_save(self):
        _storage_clear()

    def save_game(self):
        _storage_write(json.dumps({"level": self.level, "score": self.score,
                                   "lives": self.lives, "test_mode": self.test_mode,
                                   "bonus_hearts": self.bonus_hearts}))

    def new_game(self):
        self.reset()

    def continue_game(self):
        raw = _storage_read()
        try:
            data = json.loads(raw) if raw else None
        except ValueError:
            data = None
        if data is None:
            self.reset()
            return
        self.test_mode = bool(data.get("test_mode", False))
        self.level = max(1, min(MAX_LEVEL, int(data.get("level", 1))))
        self.score = int(data.get("score", 0))
        self.bonus_hearts = int(data.get("bonus_hearts", 0))
        self.anim = 0
        self._load_level()
        self.lives = int(data.get("lives", self.max_lives))

    def reset(self):
        self.level = 1
        self.bonus_hearts = 0
        self.lives = self.max_lives
        self.score = 0
        self.anim = 0
        self._load_level()

    def _load_level(self):
        self.state = "play"
        self.invuln = 0
        self.effects = []
        self.projectiles = []
        self.carrier = None
        self.respawn_lock = 0
        self.boss = None
        self.lasercat = None            # лазер+кот (уровень 12)
        self.particles = []
        self.chick = None
        self.chick_rect = None
        self.super_mode = False
        self.shoot_cd = 0
        self.player_shots = []
        self.powerup = None             # собираемый предмет-усилитель
        self.powerup_kind = None        # "double" (ур.6) | "high" (ур.13)
        self.double_jump = False
        self.high_jump = False          # «высокий прыжок» от «сырка» (ур.13)
        self.jumped_in_air = False
        self.boulders = []              # катящиеся сыры-валуны (ур.13)
        self.boulder_timer = int(BOULDER_MIN_S * FPS)
        self.boulder_enabled = (self.level == 13)
        self.wheels = []                # крутящиеся колёса (ур.14, для отрисовки оси/спиц)
        self.toast_text = ""
        self.toast_timer = 0
        self.trees = []                 # падающие деревья (уровень-лес)
        self.decor_trees = []           # декоративные деревья на фоне
        self.icy = (self.level == 9)    # скользкий ледяной уровень
        self.icicles = []               # падающие сосульки
        self.icicle_timer = ICICLE_INTERVAL
        self.ant_spits = []             # летящие плевки муравья (ур.10)
        self.puddles = []               # ядовитые лужи муравья (ур.10)
        self.quake_timer = 0
        self.quake_enabled = (self.level == 3)
        self.quake_cooldown = random.uniform(QUAKE_MIN_S, QUAKE_MAX_S) * FPS
        self.underwater = (self.level == 4)
        if self.underwater:
            start_y = 240
        elif self.level == 6:
            start_y = 402               # на стартовом облаке
        else:
            start_y = GROUND_TOP - 38
        self.player = pygame.Rect(60, start_y, 28, 38)
        self.px, self.py = float(self.player.x), float(self.player.y)
        self.vx = self.vy = 0.0
        self.on_ground = False
        self.facing = 1
        ({1: self._build_level_1, 2: self._build_level_2, 3: self._build_level_3,
          4: self._build_level_4, 5: self._build_boss, 6: self._build_clouds,
          7: self._build_forest, 8: self._build_bricks,
          9: self._build_ice, 10: self._build_ant_boss,
          11: self._build_cheese_meadow, 12: self._build_cheese_house,
          13: self._build_cheese_cellar, 14: self._build_rainbow,
          15: self._build_unicorn_boss})[self.level]()
        self.last_safe = (self.player.x, self.player.y)
        self.cam_x = float(max(0, min(self.player.centerx - WIDTH // 2,
                                      max(0, self.level_w - WIDTH))))
        self.level_banner_timer = 2 * FPS            # «УРОВЕНЬ N» на 2 секунды

    def _build_level_1(self):
        self.level_w = 3600
        self.solids = [
            (pygame.Rect(0, GROUND_TOP, 720, GROUND_H), "ground"),
            (pygame.Rect(860, GROUND_TOP, 640, GROUND_H), "ground"),
            (pygame.Rect(1640, GROUND_TOP, 860, GROUND_H), "ground"),
            (pygame.Rect(2640, GROUND_TOP, 960, GROUND_H), "ground"),
            (pygame.Rect(300, 330, 110, 40), "brick"),
            (pygame.Rect(980, 320, 120, 40), "brick"),
            (pygame.Rect(1180, 250, 120, 40), "brick"),
            (pygame.Rect(1900, 330, 120, 40), "brick"),
            (pygame.Rect(2150, 260, 140, 40), "brick"),
            (pygame.Rect(2900, 320, 120, 40), "brick"),
        ]
        self.movers = []
        self.enemies = [
            Enemy("walker", "gulya", 1180, GROUND_TOP - 32, min_x=900, max_x=1440),
            Enemy("flyer", "gus", 2380, 280, min_x=2300, max_x=2470, amp=34),
            Enemy("jumper", "jaba", 3250, GROUND_TOP - 32, floor=GROUND_TOP),
        ]
        coin_xy = [
            (330, 300), (366, 300), (740, 330), (800, 330),
            (1000, 288), (1190, 218), (1300, 330),
            (1540, 330), (1590, 330), (1930, 298), (2170, 228),
            (2540, 330), (2590, 330), (2920, 288), (3150, 330),
        ]
        self.coins = [pygame.Rect(x, y, 18, 18) for x, y in coin_xy]
        self.flag = pygame.Rect(3500, GROUND_TOP - 170, 6, 170)
        self.win_zone = pygame.Rect(3478, GROUND_TOP - 180, 50, 180)

    def _build_level_2(self):
        self.level_w = 3800
        self.solids = [
            (pygame.Rect(0, GROUND_TOP, 700, GROUND_H), "ground"),
            (pygame.Rect(960, GROUND_TOP, 540, GROUND_H), "ground"),
            (pygame.Rect(1640, GROUND_TOP, 760, GROUND_H), "ground"),
            (pygame.Rect(2560, GROUND_TOP, 1240, GROUND_H), "ground"),
            (pygame.Rect(1320, 320, 110, 40), "brick"),
            (pygame.Rect(2050, 300, 130, 40), "brick"),
            (pygame.Rect(3100, 300, 120, 40), "brick"),
        ]
        self.movers = [
            MovingPlatform(700, GROUND_TOP - 46, 110, 22, "x", 700, 850, 1.7),   # парит в яме
            MovingPlatform(1950, 356, 90, 22, "y", 250, 356, 1.4),               # не входит в землю
        ]
        self.enemies = [
            Enemy("walker", "zombie", 1050, GROUND_TOP - 32, min_x=980, max_x=1260),
            Enemy("jumper", "kot", 1850, GROUND_TOP - 32, floor=GROUND_TOP),
            Enemy("walker", "axilotle", 2720, GROUND_TOP - 32, min_x=2620, max_x=2880),
            Enemy("flyer", "popug", 3400, 290, min_x=3250, max_x=3560, amp=34),
        ]
        coin_xy = [
            (330, 330), (500, 330), (770, 330), (830, 330),
            (1100, 330), (1345, 290), (1540, 330), (1580, 330),
            (1760, 330), (2075, 270), (2115, 270),
            (2460, 330), (2500, 330), (2780, 330), (3125, 270), (3350, 330),
        ]
        self.coins = [pygame.Rect(x, y, 18, 18) for x, y in coin_xy]
        self.flag = pygame.Rect(3700, GROUND_TOP - 170, 6, 170)
        self.win_zone = pygame.Rect(3678, GROUND_TOP - 180, 50, 180)

    def _build_level_3(self):
        self.level_w = 3800
        self.solids = [
            (pygame.Rect(0, GROUND_TOP, 640, GROUND_H), "ground"),
            (pygame.Rect(800, GROUND_TOP, 560, GROUND_H), "ground"),
            (pygame.Rect(1520, GROUND_TOP, 720, GROUND_H), "ground"),
            (pygame.Rect(2400, GROUND_TOP, 1400, GROUND_H), "ground"),
            (pygame.Rect(1050, 320, 120, 40), "brick"),
            (pygame.Rect(1750, 300, 120, 40), "brick"),
            (pygame.Rect(2600, 320, 120, 40), "brick"),
            (pygame.Rect(3000, 300, 120, 40), "brick"),
        ]
        self.movers = [
            MovingPlatform(640, GROUND_TOP - 46, 100, 22, "x", 640, 700, 1.6),   # парит в яме
        ]
        self.enemies = [
            Enemy("gunner", "gunner", 900, GROUND_TOP - 34),
            Enemy("bomber", "bomber", 1850, 250, min_x=1600, max_x=2150, amp=26),
            Enemy("walker", "zombie", 2700, GROUND_TOP - 32, min_x=2500, max_x=2900),
            Enemy("jumper", "kot", 3250, GROUND_TOP - 32, floor=GROUND_TOP),
        ]
        coin_xy = [
            (330, 330), (690, 330), (900, 330), (1090, 290),
            (1250, 330), (1560, 330), (1790, 270),
            (2050, 330), (2300, 330), (2650, 290), (3050, 270),
            (3300, 330), (3450, 330),
        ]
        self.coins = [pygame.Rect(x, y, 18, 18) for x, y in coin_xy]
        self.flag = pygame.Rect(3700, GROUND_TOP - 170, 6, 170)
        self.win_zone = pygame.Rect(3678, GROUND_TOP - 180, 50, 180)

    def _build_level_4(self):
        self.level_w = 3600
        floor_h = HEIGHT - SEA_FLOOR
        self.solids = [
            (pygame.Rect(0, SEA_FLOOR, self.level_w, floor_h), "sand"),
            (pygame.Rect(700, SEA_FLOOR - 120, 60, 120), "rock"),
            (pygame.Rect(1500, SEA_FLOOR - 170, 70, 170), "rock"),
            (pygame.Rect(2400, SEA_FLOOR - 110, 60, 110), "rock"),
        ]
        self.movers = []
        self.enemies = [
            Enemy("fish", "fish", 1000, 250, min_x=850, max_x=1320),
            Enemy("emedusa", "emedusa", 1750, 240, min_x=1620, max_x=2080, amp=64),
            Enemy("fish", "fish", 2650, 320, min_x=2500, max_x=2950),
            Enemy("emedusa", "emedusa", 3050, 200, min_x=2950, max_x=3320, amp=72),
            Enemy("fish", "fish", 450, 180, min_x=300, max_x=760),
            Enemy("emedusa", "emedusa", 1300, 320, min_x=1150, max_x=1560, amp=54),
            Enemy("fish", "fish", 2150, 200, min_x=1980, max_x=2420),
            Enemy("emedusa", "emedusa", 3380, 300, min_x=3260, max_x=3540, amp=58),
        ]
        coin_xy = [
            (300, 200), (520, 300), (760, 180), (980, 360),
            (1250, 220), (1500, 150), (1780, 380), (2050, 240),
            (2350, 160), (2650, 380), (2950, 250), (3250, 200), (3450, 330),
        ]
        self.coins = [pygame.Rect(x, y, 18, 18) for x, y in coin_xy]
        self.flag = pygame.Rect(3480, WATER_SURFACE + 30, 6, SEA_FLOOR - WATER_SURFACE - 30)
        self.win_zone = pygame.Rect(3440, WATER_SURFACE, 70, SEA_FLOOR - WATER_SURFACE)

    def _build_clouds(self):                       # небо (уровень 6): движущиеся облака + гуси
        self.level_w = 3400
        self.solids = [
            (pygame.Rect(20, 440, 200, 30), "cloudbase"),                # старт
            (pygame.Rect(1240, 390, 160, 28), "cloudbase"),              # остров-чекпоинт в середине
            (pygame.Rect(self.level_w - 230, 300, 210, 30), "cloudbase"),  # финиш
        ]
        self.movers = [                              # ещё шире/медленнее, малый вертикальный ход
            MovingPlatform(300, 420, 150, 26, "x", 290, 470, 1.2, "cloud"),
            MovingPlatform(620, 380, 150, 26, "y", 340, 420, 1.1, "cloud"),
            MovingPlatform(900, 380, 150, 26, "x", 880, 1060, 1.3, "cloud"),
            MovingPlatform(1560, 360, 150, 26, "x", 1540, 1720, 1.2, "cloud"),
            MovingPlatform(1980, 380, 150, 26, "y", 340, 420, 1.2, "cloud"),
            MovingPlatform(2300, 380, 150, 26, "x", 2280, 2460, 1.3, "cloud"),
            MovingPlatform(2700, 380, 150, 26, "y", 340, 420, 1.1, "cloud"),
            MovingPlatform(3000, 360, 150, 26, "x", 2960, 3120, 1.2, "cloud"),
        ]
        self.enemies = [                             # один гусь
            Enemy("goose", "gus", self.movers[2].rect.centerx - 17,
                  self.movers[2].rect.top - 30, cloud=self.movers[2])
        ]
        coin_xy = [(360, 380), (660, 250), (960, 340), (1320, 300),
                   (1620, 320), (2040, 280), (2360, 340), (2760, 300), (3060, 320)]
        self.coins = [pygame.Rect(x, y, 18, 18) for x, y in coin_xy]
        self.powerup = pygame.Rect(120, 404, 26, 26)     # двойной прыжок — на стартовом облаке
        self.powerup_kind = "double"
        self.flag = pygame.Rect(self.level_w - 130, 130, 6, 170)
        self.win_zone = pygame.Rect(self.level_w - 150, 120, 50, 190)

    def _build_forest(self):                       # лес (уровень 7): падающие деревья + мопсы
        self.level_w = 3600
        self.solids = [
            (pygame.Rect(0, GROUND_TOP, 900, GROUND_H), "ground"),
            (pygame.Rect(1100, GROUND_TOP, 700, GROUND_H), "ground"),
            (pygame.Rect(2000, GROUND_TOP, 1600, GROUND_H), "ground"),
            (pygame.Rect(560, 320, 110, 40), "brick"),
            (pygame.Rect(2500, 320, 110, 40), "brick"),
        ]
        self.movers = []
        self.trees = [                               # деревья-мосты валятся к игроку
            FallingTree(1100, GROUND_TOP, 200, -1),  # мост ровно через яму 900..1100
            FallingTree(2000, GROUND_TOP, 200, -1),  # мост ровно через яму 1800..2000
        ]
        self.decor_trees = [(120, 170), (340, 230), (700, 150), (1300, 210),
                            (1550, 180), (2250, 240), (2700, 160), (3150, 200), (3450, 220)]
        self.enemies = [
            Enemy("flyer", "pug", 650, 250, min_x=500, max_x=850, amp=32),
            Enemy("flyer", "pug", 2350, 240, min_x=2150, max_x=2600, amp=34),
        ]
        coin_xy = [(300, 330), (560, 280), (1300, 330), (1550, 250),
                   (2300, 330), (2500, 280), (2900, 330), (3300, 330)]
        self.coins = [pygame.Rect(x, y, 18, 18) for x, y in coin_xy]
        self.flag = pygame.Rect(3500, GROUND_TOP - 170, 6, 170)
        self.win_zone = pygame.Rect(3478, GROUND_TOP - 180, 50, 180)

    def _build_bricks(self):                       # разрушаемые кирпичи + цыплёнок (уровень 8 — финал)
        self.level_w = 3600
        self.solids = [
            (pygame.Rect(0, GROUND_TOP, 1100, GROUND_H), "ground"),
            (pygame.Rect(1240, GROUND_TOP, 1000, GROUND_H), "ground"),
            (pygame.Rect(2380, GROUND_TOP, 1220, GROUND_H), "ground"),
        ]
        for bx in (360, 400, 440, 760, 800, 1500, 1540, 1580, 2600, 2640):
            top = 280 if bx in (760, 800, 2600, 2640) else 300
            self.solids.append((pygame.Rect(bx, top, 40, 40), "softbrick"))
        for bx in (1900, 1940, 1980, 3100, 3140, 3180):  # бывшие платформы — теперь тоже разрушаемые
            self.solids.append((pygame.Rect(bx, 320, 40, 40), "softbrick"))
        self.movers = []
        self.enemies = [
            Enemy("walker", "zombie", 900, GROUND_TOP - 32, min_x=820, max_x=1080),
            Enemy("jumper", "kot", 1700, GROUND_TOP - 32, floor=GROUND_TOP),
            Enemy("walker", "axilotle", 2750, GROUND_TOP - 32, min_x=2450, max_x=2980),
            Enemy("flyer", "popug", 3250, 250, min_x=3050, max_x=3400, amp=30),
        ]
        coin_xy = [(330, 330), (700, 330), (1000, 250), (1350, 330),
                   (1700, 250), (2050, 330), (2500, 330), (2900, 250), (3300, 330)]
        self.coins = [pygame.Rect(x, y, 18, 18) for x, y in coin_xy]
        softbricks = sorted((r for r, k in self.solids if k == "softbrick"), key=lambda r: r.x)
        self.chick_rect = random.choice(softbricks[:5])  # цыплёнок — в одном из первых 5 блоков
        self.flag = pygame.Rect(3500, GROUND_TOP - 170, 6, 170)
        self.win_zone = pygame.Rect(3478, GROUND_TOP - 180, 50, 180)

    def _build_ice(self):                          # ледяной финал (уровень 9): скользко, сосульки, ямы
        self.level_w = 3600
        self.solids = [                              # 4 наземных блока → 3 ямы (по 150px, уже прежних 200)
            (pygame.Rect(0, GROUND_TOP, 750, GROUND_H), "ice"),
            (pygame.Rect(900, GROUND_TOP, 650, GROUND_H), "ice"),
            (pygame.Rect(1700, GROUND_TOP, 750, GROUND_H), "ice"),
            (pygame.Rect(2600, GROUND_TOP, 1000, GROUND_H), "ice"),
            (pygame.Rect(1120, 330, 120, 40), "ice"),
            (pygame.Rect(2050, 310, 120, 40), "ice"),
        ]
        self.movers = []
        self.enemies = []                            # угроза — сосульки, а не враги
        coin_xy = [(300, 330), (560, 330), (1150, 295), (1300, 330),
                   (1900, 330), (2080, 275), (2400, 330), (2900, 330), (3300, 330)]
        self.coins = [pygame.Rect(x, y, 18, 18) for x, y in coin_xy]
        self.flag = pygame.Rect(3500, GROUND_TOP - 170, 6, 170)
        self.win_zone = pygame.Rect(3478, GROUND_TOP - 180, 50, 180)

    def _build_boss(self):                         # арена промежуточного босса (уровень 5)
        self.level_w = WIDTH
        self.solids = [
            (pygame.Rect(0, GROUND_TOP, WIDTH, GROUND_H), "ground"),
            (pygame.Rect(110, 300, 120, 30), "brick"),
            (pygame.Rect(WIDTH - 230, 300, 120, 30), "brick"),
        ]
        self.movers = []
        self.enemies = []
        self.coins = []
        self.boss = Boss(WIDTH // 2 - 42, BOSS_HOVER_Y)
        self.flag = pygame.Rect(0, 0, 0, 0)
        self.win_zone = pygame.Rect(-100, -100, 1, 1)

    def _build_ant_boss(self):                     # финальный босс: гигантский муравей
        self.level_w = 1440
        self.solids = [
            (pygame.Rect(0, GROUND_TOP, self.level_w, GROUND_H), "ground"),
            (pygame.Rect(150, 308, 150, 24), "brick"),     # нижняя лесенка (с пола)
            (pygame.Rect(1140, 308, 150, 24), "brick"),
            (pygame.Rect(430, 250, 165, 24), "brick"),     # средний ярус
            (pygame.Rect(845, 250, 165, 24), "brick"),
            (pygame.Rect(600, 192, 240, 24), "brick"),     # верхняя площадка-укрытие
        ]
        self.movers = []
        self.enemies = []
        self.coins = []
        self.boss = AntBoss(self.level_w // 2 - ANT_W // 2, GROUND_TOP)
        head_y = GROUND_TOP - ANT_H                 # кирпичи, под которыми голова закрыта для прыжка
        self.boss.no_go = [(r.left - ANT_STOP_MARGIN, r.right + ANT_STOP_MARGIN)
                           for r, k in self.solids
                           if k == "brick" and 0 <= head_y - r.bottom < ANT_HEAD_CLEARANCE]
        self.flag = pygame.Rect(0, 0, 0, 0)
        self.win_zone = pygame.Rect(-100, -100, 1, 1)

    def _build_cheese_meadow(self):                # уровень 11: сырные горы-ступени + мыши
        self.level_w = 3600
        self.solids = [                            # сырный пол с тремя ямами
            (pygame.Rect(0, GROUND_TOP, 700, GROUND_H), "cheese"),
            (pygame.Rect(820, GROUND_TOP, 700, GROUND_H), "cheese"),
            (pygame.Rect(1640, GROUND_TOP, 700, GROUND_H), "cheese"),
            (pygame.Rect(2460, GROUND_TOP, 1140, GROUND_H), "cheese"),
        ]
        cheese_steps = [                           # лесенки из сыра — подниматься вверх
            (250, 358, 110), (380, 308, 110), (510, 258, 140),
            (980, 332, 110), (1120, 282, 110), (1260, 232, 150),
            (1780, 338, 120), (1930, 288, 120), (2080, 238, 150),
            (2600, 350, 120), (2770, 300, 120), (2940, 250, 130),
            (3060, 210, 230),                      # верхняя площадка с флагом
        ]
        for sx, sy, sw in cheese_steps:
            self.solids.append((pygame.Rect(sx, sy, sw, 40), "cheese"))
        self.movers = []
        self.enemies = [                           # белые — быстрые; серые — толстые (2 HP)
            Enemy("walker", "mouse_white", 1000, GROUND_TOP - 32, min_x=820, max_x=1500,
                  speed=MOUSE_WHITE_SPEED),
            Enemy("walker", "mouse_white", 1320, 232 - 32, min_x=1260, max_x=1410,
                  speed=MOUSE_WHITE_SPEED),
            Enemy("walker", "mouse_white", 2900, GROUND_TOP - 32, min_x=2460, max_x=3010,
                  speed=MOUSE_WHITE_SPEED),
            Enemy("walker", "mouse_gray", 1760, GROUND_TOP - 32, min_x=1640, max_x=2320,
                  speed=MOUSE_GRAY_SPEED, hp=MOUSE_GRAY_HP),
            Enemy("walker", "mouse_gray", 2620, GROUND_TOP - 32, min_x=2460, max_x=2900,
                  speed=MOUSE_GRAY_SPEED, hp=MOUSE_GRAY_HP),
        ]
        coin_xy = [(300, 330), (410, 280), (545, 228), (740, 360),
                   (1010, 302), (1150, 252), (1300, 202),
                   (1700, 360), (1970, 258), (2120, 208),
                   (2500, 360), (2810, 270), (2980, 220), (3160, 178)]
        self.coins = [pygame.Rect(x, y, 18, 18) for x, y in coin_xy]
        self.flag = pygame.Rect(3200, 60, 6, 150)
        self.win_zone = pygame.Rect(3150, 50, 90, 170)
        self._toast("Сырная поляна!")

    def _build_cheese_house(self):                 # уровень 12 (финал): лазер + кот-охотник
        self.level_w = 2600
        self.solids = [
            (pygame.Rect(0, GROUND_TOP, self.level_w, GROUND_H), "cheese"),     # сырный пол
        ]
        shelves = [(320, 322, 130), (640, 268, 130), (980, 322, 130),
                   (1320, 262, 150), (1700, 322, 130), (2020, 270, 140)]
        for sx, sy, sw in shelves:                  # полки — куда отпрыгнуть от кота
            self.solids.append((pygame.Rect(sx, sy, sw, 28), "cheese"))
        self.movers = []
        self.enemies = []
        coin_xy = [(360, 292), (700, 238), (1040, 292), (1380, 232),
                   (1760, 292), (2080, 240), (2300, 360)]
        self.coins = [pygame.Rect(x, y, 18, 18) for x, y in coin_xy]
        self.lasercat = LaserCat(int(self.level_w * 0.62), GROUND_TOP, self.level_w)
        self.flag = pygame.Rect(2500, GROUND_TOP - 170, 6, 170)
        self.win_zone = pygame.Rect(2460, GROUND_TOP - 180, 70, 180)
        self._toast("Сырный дом: уворачивайся от кота!")

    def _build_cheese_cellar(self):                # уровень 13 (финал): мыши+крысы+кот+валуны
        self.level_w = 5800                        # длинный финал (вдвое)
        self.solids = [
            (pygame.Rect(0, GROUND_TOP, self.level_w, GROUND_H), "cheese"),     # сплошной сырный пол
        ]
        # уступы высоко (top ≤ 250) — чтобы большой валун (верх ~280) проходил под ними
        shelves = [(300, 250, 150, "cheese"), (640, 196, 150, "rock"),
                   (1040, 250, 160, "cheese"), (1440, 196, 150, "rock"),
                   (1880, 250, 160, "cheese"), (2320, 196, 150, "rock"),
                   (2760, 250, 160, "cheese"), (3200, 196, 150, "rock"),
                   (3640, 250, 160, "cheese"), (4080, 196, 150, "rock"),
                   (4520, 250, 160, "cheese"), (4960, 196, 150, "rock"),
                   (5360, 250, 200, "cheese")]
        for sx, sy, sw, kind in shelves:            # уступы — спрятаться от валунов и кота
            self.solids.append((pygame.Rect(sx, sy, sw, 28), kind))
        self.movers = []
        MW, MG, HP = MOUSE_WHITE_SPEED, MOUSE_GRAY_SPEED, MOUSE_GRAY_HP
        self.enemies = [
            Enemy("walker", "mouse_white", 700, GROUND_TOP - 32, min_x=450, max_x=1000, speed=MW),
            Enemy("walker", "mouse_white", 1700, GROUND_TOP - 32, min_x=1450, max_x=2000, speed=MW),
            Enemy("walker", "mouse_white", 2700, GROUND_TOP - 32, min_x=2450, max_x=3000, speed=MW),
            Enemy("walker", "mouse_white", 3700, GROUND_TOP - 32, min_x=3450, max_x=4000, speed=MW),
            Enemy("walker", "mouse_white", 4700, GROUND_TOP - 32, min_x=4450, max_x=5000, speed=MW),
            Enemy("walker", "mouse_gray", 1250, GROUND_TOP - 32, min_x=1050, max_x=1550, speed=MG, hp=HP),
            Enemy("walker", "mouse_gray", 2250, GROUND_TOP - 32, min_x=2050, max_x=2550, speed=MG, hp=HP),
            Enemy("walker", "mouse_gray", 3250, GROUND_TOP - 32, min_x=3050, max_x=3550, speed=MG, hp=HP),
            Enemy("walker", "mouse_gray", 4250, GROUND_TOP - 32, min_x=4050, max_x=4550, speed=MG, hp=HP),
            Enemy("walker", "mouse_gray", 5150, GROUND_TOP - 32, min_x=4900, max_x=5400, speed=MG, hp=HP),
        ]
        coin_xy = [(360, 360), (375, 222), (700, 168), (1080, 222), (1300, 360),
                   (1500, 168), (1920, 222), (2150, 360), (2380, 168), (2800, 222),
                   (3000, 360), (3260, 168), (3680, 222), (3900, 360), (4140, 168),
                   (4560, 222), (4780, 360), (5020, 168), (5400, 222), (5600, 360)]
        self.coins = [pygame.Rect(x, y, 18, 18) for x, y in coin_xy]
        self.powerup = pygame.Rect(150, 366, 26, 26)      # «сырок» — высокий прыжок (на старте)
        self.powerup_kind = "high"
        self.lasercat = LaserCat(int(self.level_w * 0.6), GROUND_TOP, self.level_w, speed_mult=2.0)
        self.flag = pygame.Rect(5680, GROUND_TOP - 170, 6, 170)
        self.win_zone = pygame.Rect(5640, GROUND_TOP - 180, 70, 180)
        self._toast("Сырный подвал — финал! Возьми сырок: высокий прыжок")

    def _build_rainbow(self):                      # уровень 14 (финал): облака + колёса + единороги
        self.level_w = 4000
        seg = [(0, 600), (1100, 580), (2180, 580), (3260, 740)]    # облачный пол с тремя ямами
        self.solids = [(pygame.Rect(x, GROUND_TOP, w, GROUND_H), "cloudbase") for x, w in seg]
        self.movers = []
        self.wheels = []
        for i, cx in enumerate([760, 940, 1840, 2020, 2920, 3100]):   # по 2 колеса на яму
            spokes = []
            for k in range(WHEEL_SPOKES):          # лопасти-платформы (фазы колёс смещены)
                a = i * (math.pi / 4) + k * (2 * math.pi / WHEEL_SPOKES)
                sp = WheelSpoke(cx, GROUND_TOP, WHEEL_R, a, WHEEL_SPEED)
                spokes.append(sp)
                self.movers.append(sp)
            self.wheels.append({"cx": cx, "cy": GROUND_TOP, "r": WHEEL_R, "spokes": spokes})
        self.enemies = [
            Enemy("walker", "unicorn", 360, GROUND_TOP - 32, min_x=120, max_x=560),
            Enemy("walker", "unicorn", 1350, GROUND_TOP - 32, min_x=1140, max_x=1640),
            Enemy("walker", "unicorn", 2430, GROUND_TOP - 32, min_x=2220, max_x=2720),
            Enemy("walker", "unicorn", 3600, GROUND_TOP - 32, min_x=3320, max_x=3840),
        ]
        coin_xy = [(300, 360), (760, 288), (940, 288), (1350, 360),
                   (1840, 288), (2020, 288), (2430, 360),
                   (2920, 288), (3100, 288), (3500, 360), (3820, 360)]
        self.coins = [pygame.Rect(x, y, 18, 18) for x, y in coin_xy]
        self.flag = pygame.Rect(3880, GROUND_TOP - 170, 6, 170)
        self.win_zone = pygame.Rect(3840, GROUND_TOP - 180, 70, 180)
        self._toast("Радужный мир — финал! Прыгай по колёсам над ямами")

    def _build_unicorn_boss(self):                 # уровень 15 (финал): большой единорог + радужный луч
        self.level_w = 1600
        self.solids = [
            (pygame.Rect(0, GROUND_TOP, self.level_w, GROUND_H), "cloudbase"),  # облачный пол
            (pygame.Rect(60, 290, 150, 24), "cloudbase"),                       # уступы — подняться
            (pygame.Rect(self.level_w - 210, 290, 150, 24), "cloudbase"),       #   к платформам
        ]
        self.movers = [                            # движущиеся тучи НАД боссом (выше зоны луча)
            MovingPlatform(250, 250, 140, 22, "x", 250, 600, 1.7, "cloud"),
            MovingPlatform(680, 250, 140, 22, "x", 660, 1000, 2.0, "cloud"),
            MovingPlatform(1110, 250, 140, 22, "x", 1050, 1350, 1.7, "cloud"),
        ]
        self.wheels = []
        self.enemies = []
        self.coins = []
        self.boss = UnicornBoss(self.level_w // 2 - UNI_W // 2, GROUND_TOP)
        self.flag = pygame.Rect(0, 0, 0, 0)
        self.win_zone = pygame.Rect(-100, -100, 1, 1)
        self._toast("Единорог! Беги по тучам, после радужного луча — прыгай на голову")

    # --- шаг симуляции ---
    def update(self, left, right, up, down, jump):
        if self.state != "play":
            return
        self.anim += 1
        if self.invuln > 0:
            self.invuln -= 1
        for fx in self.effects[:]:
            fx["timer"] -= 1
            if fx["timer"] <= 0:
                self.effects.remove(fx)

        if self.underwater:
            self._swim(left, right, up, down)
        else:
            self._walk(left, right, jump)

        for e in self.enemies:
            e.update()
            if e.alive and e.kind in ("gunner", "bomber"):
                e.shoot_timer -= 1
                if e.shoot_timer <= 0:
                    e.shoot_timer = SHOOT_INTERVAL
                    self._fire(e)
        self._check_enemies()
        if self.state != "play":
            return
        self._update_projectiles()
        if self.state != "play":
            return

        for t in self.trees:
            if t.phase == "stand" and abs(self.player.centerx - t.base_x) < TREE_TRIGGER_DIST:
                t.trigger()
            t.update()
            if t.phase == "fall" and self.invuln == 0 and self.player.colliderect(t.hit_rect()):
                self._take_damage()
        if self.state != "play":
            return

        if self.icy:
            self.icicle_timer -= 1
            if self.icicle_timer <= 0:
                self.icicle_timer = ICICLE_INTERVAL
                sx = self.player.centerx + random.randint(-WIDTH // 2 + 40, WIDTH // 2 - 40)
                sx = max(20, min(self.level_w - 20, sx))
                self.icicles.append({"x": float(sx), "y": float(-ICICLE_H), "vy": 0.0})
            for ic in self.icicles[:]:
                ic["vy"] = min(ic["vy"] + ICICLE_GRAV, ICICLE_MAX)
                ic["y"] += ic["vy"]
                r = pygame.Rect(int(ic["x"]) - ICICLE_W // 2, int(ic["y"]), ICICLE_W, ICICLE_H)
                if self.invuln == 0 and r.colliderect(self.player):
                    self.icicles.remove(ic)
                    self._take_damage()
                    continue
                if ic["y"] > LEVEL_H or any(r.colliderect(s) for s, _ in self.solids):
                    self.icicles.remove(ic)
            if self.state != "play":
                return

        for c in self.coins[:]:
            if self.player.colliderect(c):
                self.coins.remove(c)
                self.score += COIN_SCORE
                play("coin")
                self._spawn_particles(c.centerx, c.centery, 7, (255, 220, 90),
                                      spread=2.6, up=2.6, size=4, life=26, grav=0.6)
                self._spawn_popup(c.centerx, c.centery, f"+{COIN_SCORE}", (255, 225, 80))

        if self.shoot_cd > 0:
            self.shoot_cd -= 1
        if self.toast_timer > 0:
            self.toast_timer -= 1
        if self.level_banner_timer > 0:
            self.level_banner_timer -= 1
        if self.powerup is not None and self.player.colliderect(self.powerup):
            kind = self.powerup_kind
            self.powerup = None
            play("powerup")
            if kind == "high":
                self.high_jump = True
                self._toast("Высокий прыжок!")
            else:
                self.double_jump = True
                self._toast("Двойной прыжок!")
        for p in self.particles[:]:
            p["vx"] *= 0.98
            p["vy"] += 0.4 * p.get("grav", 1.0)
            p["x"] += p["vx"]
            p["y"] += p["vy"]
            p["life"] -= 1
            if p["life"] <= 0:
                self.particles.remove(p)
        self._update_player_shots()
        if self.chick is not None and self.chick.alive:
            self.chick.update(self.player, self.solids, self.level_w)
            if self.player.colliderect(self.chick.rect):     # поймал — супер-форма
                self.chick.alive = False
                self.super_mode = True
                play("super")
                self._spawn_popup(self.player.centerx, self.player.top - 6, "СУПЕР!", (120, 220, 255))

        if self.lasercat is not None:                        # лазер + кот (ур.12-13)
            self.lasercat.update(self.player)
            if (self.lasercat.phase == "leap" and self.invuln == 0
                    and self.player.colliderect(self.lasercat.cat)):
                self._take_damage()
            if self.state != "play":
                return

        if self.boulder_enabled:                             # катящиеся валуны (ур.13)
            self._update_boulders()
            if self.state != "play":
                return

        if self.boss is not None:
            self.boss.update(self.player, GROUND_TOP, self.level_w)
            for s in getattr(self.boss, "new_spits", ()):   # муравей выплюнул залп
                self._spawn_spit(*s)
            self._update_ant_hazards()
            self._update_boss_beam()            # радужный луч единорога (ур.15)
            if self.state != "play":
                return
            self._check_boss()
            if self.state == "play" and not self.boss.alive and not self.boss.dying:
                if self.level < MAX_LEVEL:          # промежуточный босс — идём дальше
                    if not self.test_mode:
                        self.bonus_hearts += 1      # награда за босса: +1 макс. сердце
                    play("levelup")
                    self.level += 1
                    self._load_level()
                    self.lives = self.max_lives     # полное здоровье с учётом бонуса
                    if not self.test_mode:
                        self._toast("Босс повержен! +1 макс. сердце")
                    self.save_game()                # чекпоинт после босса
                else:                               # финальный босс — новое сохранение + победа
                    self.save_game()
                    self.state = "win"
                    play("win")
            return

        if not self.underwater and self.player.top > LEVEL_H + 80:
            self._fall_in_pit()
            return

        if self.player.colliderect(self.win_zone):
            if self.level < MAX_LEVEL:
                play("levelup")
                self.level += 1
                self._load_level()
                self.lives = self.max_lives         # восстановление здоровья на новом уровне
            else:
                self.save_game()                    # финал (сырный дом) — сохраняем перед победой
                self.state = "win"
                play("win")

    def _update_boss_beam(self):                 # направленный луч единорога: бьёт по линии в игрока
        b = self.boss
        if not getattr(b, "beam_on", False) or self.invuln != 0:
            return
        ox, oy = b.beam_origin
        dx, dy = math.cos(b.beam_angle), math.sin(b.beam_angle)
        px, py = self.player.centerx - ox, self.player.centery - oy
        proj = px * dx + py * dy                  # вдоль луча
        if proj < 0 or proj > UNI_BEAM_LEN:       # позади рога или дальше конца луча
            return
        if abs(px * -dy + py * dx) < UNI_BEAM_HALF + 14:    # перпенд. расстояние до оси + радиус игрока
            self._take_damage()

    def _check_boss(self):
        b = self.boss
        if not b.alive or not self.player.colliderect(b.rect):
            return
        if b.phase == "stunned":                    # уязвим — бьём прыжком на голову
            if self.vy > 0 and self.player.bottom <= b.rect.top + 20 and b.invuln == 0:
                if b.hit():
                    self.score += 500
                    play("boss_hit")
                    self._spawn_popup(b.rect.centerx, b.rect.top, "-1 HP", (255, 120, 120))
                    self.vy = -BOSS_STOMP_BOUNCE     # отскок вдвое — чтобы не упасть обратно
                    self.py = float(self.player.y)
        elif self.invuln == 0 and b.invuln == 0:    # пока босс отшатнулся от удара — не ранит
            self._take_damage()

    def _spawn_spit(self, x, y, vx, vy):
        self.ant_spits.append({"rect": pygame.Rect(int(x) - SPIT_R, int(y) - SPIT_R, SPIT_R * 2, SPIT_R * 2),
                               "fx": float(x), "fy": float(y), "vx": vx, "vy": vy})

    def _add_puddle(self, x):
        cx = max(PUDDLE_W // 2, min(self.level_w - PUDDLE_W // 2, int(x)))
        self.puddles.append({"rect": pygame.Rect(cx - PUDDLE_W // 2, GROUND_TOP - PUDDLE_H, PUDDLE_W, PUDDLE_H),
                             "timer": PUDDLE_LIFE})

    def _update_ant_hazards(self):
        for s in self.ant_spits[:]:                 # летящие капли кислоты
            s["vy"] = min(s["vy"] + SPIT_GRAV, MAX_FALL)
            s["fx"] += s["vx"]
            s["fy"] += s["vy"]
            s["rect"].center = (round(s["fx"]), round(s["fy"]))
            if self.invuln == 0 and s["rect"].colliderect(self.player):
                self.ant_spits.remove(s)
                self._take_damage()
                continue
            if s["fy"] >= GROUND_TOP:               # шлёпнулась на пол → лужа
                self.ant_spits.remove(s)
                self._add_puddle(s["fx"])
            elif s["fx"] < -20 or s["fx"] > self.level_w + 20:
                self.ant_spits.remove(s)
        for p in self.puddles[:]:                   # ядовитые лужи
            p["timer"] -= 1
            if p["timer"] <= 0:
                self.puddles.remove(p)
                continue
            if self.invuln == 0 and self.player.colliderect(p["rect"]):
                self._take_damage()

    def _update_boulders(self):                     # катящиеся сыры-валуны (ур.13)
        self.boulder_timer -= 1
        if self.boulder_timer <= 0:
            self.boulder_timer = random.randint(int(BOULDER_MIN_S * FPS), int(BOULDER_MAX_S * FPS))
            r = random.randint(BOULDER_R - 4, BOULDER_R + 6)
            sx = self.player.centerx + WIDTH // 2 + 60      # вкатывается справа из-за края экрана
            self.boulders.append({"fx": float(sx), "r": r, "spin": 0.0,
                                  "rect": pygame.Rect(sx - r, GROUND_TOP - 2 * r, 2 * r, 2 * r)})
        for b in self.boulders[:]:
            b["fx"] -= BOULDER_SPEED
            b["spin"] -= BOULDER_SPEED / b["r"]             # вращение для отрисовки
            b["rect"].center = (round(b["fx"]), GROUND_TOP - b["r"])
            if b["rect"].right < -40:
                self.boulders.remove(b)
                continue
            if self.invuln == 0 and self.player.colliderect(b["rect"]):
                self._take_damage()                         # валун катится дальше, не исчезает

    def _walk(self, left, right, jump):
        self._update_quake()
        if self.respawn_lock > 0:
            self.respawn_lock -= 1
            left = right = jump = False
        if self.quake_timer > 0:
            if self.on_ground and self.quake_timer % 16 == 0:
                self.vy = -4.5
                self.on_ground = False
            self.px += random.uniform(-1.3, 1.3)

        for m in self.movers:
            m.update()
        if self.carrier is not None and self.on_ground:
            self.px += self.carrier.dx
            self.player.x = round(self.px)
            self.player.bottom = self.carrier.rect.top
            self.py = float(self.player.y)

        target_vx = (float(bool(right)) - float(bool(left))) * MOVE_SPEED
        if self.icy:
            self.vx += (target_vx - self.vx) * ICE_ACCEL    # скользко: инерция разгона/торможения
        else:
            self.vx = target_vx
        if right and not left:
            self.facing = 1
        elif left and not right:
            self.facing = -1
        self.px += self.vx
        self.player.x = round(self.px)
        before_x = self.player.x
        self._collide_axis(self.vx, 0)
        if self.player.x != before_x:
            self.px = float(self.player.x)

        if jump:
            js = JUMP_SPEED * HIGH_JUMP_MULT if self.high_jump else JUMP_SPEED
            if self.on_ground:
                self.vy = -js
                self.on_ground = False
                play("jump")
                self._spawn_particles(self.player.centerx, self.player.bottom, 5,
                                      (210, 204, 186), spread=2.4, up=0.4, size=4, life=20, grav=0.7)
            elif self.double_jump and not self.jumped_in_air:   # двойной прыжок в воздухе
                self.vy = -js
                self.jumped_in_air = True
                play("jump")

        self.vy = min(self.vy + GRAVITY, MAX_FALL)
        self.py += self.vy
        self.player.y = round(self.py)
        before_y = self.player.y
        fall_v = self.vy
        self.on_ground = False
        self.carrier = None
        self._collide_axis(0, self.vy)
        if self.player.y != before_y:
            self.py = float(self.player.y)
        if self.on_ground:
            self.jumped_in_air = False                  # приземлились — двойной прыжок снова доступен
            if fall_v > 8.5:                            # жёсткое приземление — облачко пыли
                self._spawn_particles(self.player.centerx, self.player.bottom, 7,
                                      (210, 204, 186), spread=4.0, up=0.6, size=4, life=22, grav=0.7)
            elif abs(self.vx) > 0.6 and self.anim % 9 == 0:    # пыль из-под ног при беге
                self._spawn_particles(self.player.centerx - self.facing * 6, self.player.bottom,
                                      1, (212, 206, 190), spread=1.0, up=0.3, size=3, life=16, grav=0.6)
            if self.carrier is None:
                self.last_safe = (self.player.x, self.player.y)

    def _swim(self, left, right, up, down):
        tx = (float(bool(right)) - float(bool(left))) * SWIM_SPEED
        ty = (float(bool(down)) - float(bool(up))) * SWIM_SPEED
        self.vx += (tx - self.vx) * SWIM_ACCEL
        self.vy += (ty - self.vy) * SWIM_ACCEL
        if self.vx > 0.3:
            self.facing = 1
        elif self.vx < -0.3:
            self.facing = -1

        self.px += self.vx
        self.player.x = round(self.px)
        before_x = self.player.x
        self._collide_axis(self.vx, 0)
        if self.player.x != before_x:
            self.px = float(self.player.x)
            self.vx = 0.0

        self.py += self.vy
        self.player.y = round(self.py)
        before_y = self.player.y
        self._collide_axis(0, self.vy)
        if self.player.top < WATER_SURFACE:               # поверхность воды
            self.player.top = WATER_SURFACE
        if self.player.y != before_y:
            self.py = float(self.player.y)
            self.vy = 0.0

    def _update_quake(self):
        if self.quake_timer > 0:
            self.quake_timer -= 1
            if self.quake_timer == 0:
                self.quake_cooldown = random.uniform(QUAKE_MIN_S, QUAKE_MAX_S) * FPS
        elif self.quake_enabled:
            self.quake_cooldown -= 1
            if self.quake_cooldown <= 0:
                self.quake_timer = int(QUAKE_DUR_S * FPS)

    def _fire(self, e):
        if e.kind == "gunner":
            d = 1 if self.player.centerx >= e.rect.centerx else -1
            self._spawn_projectile(e.rect.centerx, e.rect.centery - 2, d * PROJ_SPEED, 0.0)
        else:
            self._spawn_projectile(e.rect.centerx, e.rect.bottom, 0.0, PROJ_SPEED)

    def _spawn_projectile(self, x, y, vx, vy):
        self.projectiles.append({
            "rect": pygame.Rect(int(x) - PROJ_R, int(y) - PROJ_R, PROJ_R * 2, PROJ_R * 2),
            "fx": float(x), "fy": float(y), "vx": vx, "vy": vy,
        })

    def _update_projectiles(self):
        for p in self.projectiles[:]:
            p["fx"] += p["vx"]
            p["fy"] += p["vy"]
            p["rect"].center = (round(p["fx"]), round(p["fy"]))
            r = p["rect"]
            if (r.right < 0 or r.left > self.level_w or r.top > LEVEL_H + 40 or r.bottom < -40):
                self.projectiles.remove(p)
                continue
            if any(r.colliderect(s) for s, _ in self.solids):
                self.projectiles.remove(p)
                continue
            if r.colliderect(self.player):
                self.projectiles.remove(p)
                if self.invuln == 0:
                    self._take_damage()
                continue

    def _colliders(self):
        cols = [(r, None, k) for r, k in self.solids]
        for m in self.movers:
            cols.append((m.rect, m, m.visual))
        for t in self.trees:
            if t.phase == "fallen":                  # упавший ствол — мост-платформа
                cols.append((t.fallen_rect, None, "log"))
        return cols

    def _collide_axis(self, vx, vy):
        broke = []
        for rect, mover, kind in self._colliders():
            if not self.player.colliderect(rect):
                continue
            if vx > 0:
                self.player.right = rect.left
            elif vx < 0:
                self.player.left = rect.right
            elif vy > 0:
                self.player.bottom = rect.top
                self.vy = 0
                self.on_ground = True
                self.carrier = mover
            elif vy < 0:
                self.player.top = rect.bottom
                self.vy = 0
                if kind == "softbrick":              # удар головой снизу — кирпич ломается
                    broke.append(rect)
        for rect in broke:
            self._break_brick(rect)
        if self.player.left < 0:
            self.player.left = 0
        if self.player.right > self.level_w:
            self.player.right = self.level_w

    def _break_brick(self, rect):
        play("brick")
        for i, (r, k) in enumerate(self.solids):
            if r is rect:
                self.solids.pop(i)
                break
        self._spawn_particles(rect.centerx, rect.centery, 8, (175, 125, 85),
                              spread=3.2, up=4.0, size=5, life=32)
        self.score += 50
        if rect is self.chick_rect:                  # в этом кирпиче сидел цыплёнок
            self.chick = Chick(rect.centerx - 11, rect.top - 26)
            self.chick_rect = None

    def _update_player_shots(self):
        for s in self.player_shots[:]:
            s["fx"] += s["vx"]
            s["rect"].centerx = round(s["fx"])
            r = s["rect"]
            if r.right < 0 or r.left > self.level_w:
                self.player_shots.remove(s)
                continue
            if any(r.colliderect(rr) for rr, k in self.solids if k not in ("cloudbase", "softbrick")):
                self.player_shots.remove(s)
                continue
            for e in self.enemies:
                if e.alive and e.stompable and r.colliderect(e.rect):
                    if e.hit_stomp():
                        self.score += STOMP_SCORE
                        self._spawn_popup(e.rect.centerx, e.rect.top, f"+{STOMP_SCORE}", (255, 255, 255))
                    else:
                        self._spawn_popup(e.rect.centerx, e.rect.top, "-1", (255, 205, 120))
                    if s in self.player_shots:
                        self.player_shots.remove(s)
                    break

    def super_shoot(self):
        if not self.super_mode or self.shoot_cd > 0:
            return
        self.shoot_cd = SUPER_SHOT_CD
        play("shoot")
        r = pygame.Rect(0, 0, SUPER_SHOT_R * 2, SUPER_SHOT_R * 2)
        r.center = (self.player.centerx, self.player.centery)
        self.player_shots.append({"rect": r, "fx": float(r.centerx),
                                  "vx": SUPER_SHOT_SPEED * self.facing})

    def _check_enemies(self):
        for e in self.enemies:
            if not e.alive or not self.player.colliderect(e.rect):
                continue
            if e.stompable and self.vy > 0 and self.player.bottom <= e.rect.top + 18:
                self.vy = -STOMP_BOUNCE
                self.py = float(self.player.y)
                play("stomp")
                self._spawn_particles(e.rect.centerx, e.rect.top, 8, (255, 240, 200),
                                      spread=3.4, up=2.0, size=4, life=24, grav=0.7)
                if e.hit_stomp():                   # погиб
                    self.score += STOMP_SCORE
                    self._spawn_popup(e.rect.centerx, e.rect.top, f"+{STOMP_SCORE}", (255, 255, 255))
                else:                               # ранен, но жив (серая мышь)
                    self._spawn_popup(e.rect.centerx, e.rect.top, "-1", (255, 205, 120))
            elif self.invuln == 0:
                self._take_damage()
                return

    def _take_damage(self):
        self.lives -= 1
        if self.lives <= 0:
            self.lives = 0
            self.state = "lose"
            self.menu_index = 0
            play("lose")
            return
        self.invuln = INVULN_FRAMES
        play("hurt")
        if not self.underwater:
            self.vy = -7.0
            self.py = float(self.player.y)

    def _fall_in_pit(self):
        play("pit")
        self.lives -= 1
        if self.lives <= 0:
            self.lives = 0
            self.state = "lose"
            self.menu_index = 0
            play("lose")
            return
        self.player.x, self.player.y = self.last_safe
        self.px, self.py = float(self.player.x), float(self.player.y)
        self.vx = self.vy = 0.0
        self.invuln = INVULN_FRAMES
        self.respawn_lock = RESPAWN_LOCK_FRAMES

    def _spawn_popup(self, x, y, text, color):
        self.effects.append({"x": x, "y": y, "text": text, "color": color,
                             "timer": EFFECT_FRAMES, "life": EFFECT_FRAMES})

    def _spawn_particles(self, x, y, n, color, spread=3.0, up=2.0, size=5,
                         life=30, grav=1.0):
        if len(self.particles) > 150:            # жёсткий лимит — без раздувания
            return
        for _ in range(n):
            self.particles.append({
                "x": float(x), "y": float(y),
                "vx": random.uniform(-spread, spread),
                "vy": random.uniform(-up - 2.0, -up + 1.0),
                "life": life, "life0": life, "color": color, "grav": grav,
                "size": random.randint(max(2, size - 1), size + 1)})

    def _toast(self, text):
        self.toast_text = text
        self.toast_timer = TOAST_FRAMES


# =====================================================================
#  Отрисовка (ox/oy — общий сдвиг для буфера тряски)
# =====================================================================

def _scale_xy(sprite, sx, sy):
    w, h = sprite.get_size()
    return pygame.transform.smoothscale(sprite, (max(1, round(w * sx)), max(1, round(h * sy))))


def _blit_bottom(surf, sprite, rect, cam_x, ox, oy, dy=0):
    x = rect.centerx - cam_x + ox - sprite.get_width() // 2
    y = rect.bottom - sprite.get_height() + dy + oy
    surf.blit(sprite, (x, y))


def _blit_center(surf, sprite, rect, cam_x, ox, oy):
    surf.blit(sprite, sprite.get_rect(center=(rect.centerx - cam_x + ox, rect.centery + oy)))


def _draw_player(surf, game, assets, cam_x, ox, oy):
    spr = assets["bubuza"]
    if game.facing < 0:
        spr = pygame.transform.flip(spr, True, False)
    if game.super_mode:                              # аура супер-формы
        gr = pygame.Surface((game.player.width + 26, game.player.height + 26), pygame.SRCALPHA)
        a = 80 + int(40 * math.sin(game.anim * 0.2))
        pygame.draw.ellipse(gr, (130, 225, 255, a), gr.get_rect())
        surf.blit(gr, (game.player.centerx - cam_x + ox - gr.get_width() // 2,
                       game.player.centery + oy - gr.get_height() // 2))
    if game.underwater:
        f = math.sin(game.anim * 0.1) * 0.05
        spr = _scale_xy(spr, 1 - f * 0.6, 1 + f)
        _blit_center(surf, spr, game.player, cam_x, ox, oy)
        return
    if game.on_ground:
        f = math.sin(game.anim * 0.12) * 0.05
    else:
        f = max(-0.18, min(0.18, -game.vy * 0.012))
    spr = _scale_xy(spr, 1 - f * 0.7, 1 + f)
    if game.on_ground and game.vx:                       # наклон вперёд при беге
        spr = pygame.transform.rotate(spr, -game.facing * 5)
    elif not game.on_ground:                             # наклон по инерции в прыжке
        spr = pygame.transform.rotate(spr, max(-10, min(10, -game.vx * 1.2)))
    bob = -round(abs(math.sin(game.anim * 0.35)) * 3) if (game.on_ground and game.vx) else 0
    _blit_bottom(surf, spr, game.player, cam_x, ox, oy, bob)


def _draw_enemy(surf, e, assets, cam_x, ox, oy):
    spr = assets[e.skin]
    if e.dying:
        t = max(0.0, e.death_timer / DEATH_FRAMES)
        flat = _scale_xy(spr, 1 + (1 - t) * 0.5, max(0.06, t))
        flat = flat.copy()
        flat.set_alpha(int(255 * t))
        _blit_bottom(surf, flat, e.rect, cam_x, ox, oy)
        return
    if e.kind in ("walker", "fish"):
        if e.dir > 0:
            spr = pygame.transform.flip(spr, True, False)
        if e.flash > 0 and (e.flash // 3) % 2 == 0:    # вспышка после непробившего удара
            spr = spr.copy()
            spr.fill((180, 40, 40), special_flags=pygame.BLEND_RGB_ADD)
        if e.kind == "fish":
            _blit_center(surf, spr, e.rect, cam_x, ox, oy)
        else:
            bob = -round(abs(math.sin(e.rect.x * 0.18)) * 3)
            _blit_bottom(surf, spr, e.rect, cam_x, ox, oy, bob)
    elif e.kind in ("flyer", "bomber"):
        if e.dir > 0:
            spr = pygame.transform.flip(spr, True, False)
        rot = pygame.transform.rotate(spr, math.sin(e.phase) * 8)
        surf.blit(rot, rot.get_rect(center=(e.rect.centerx - cam_x + ox, e.rect.centery + oy)))
    elif e.kind == "emedusa":
        sq = 1 + math.sin(e.phase * 2) * 0.06
        spr = _scale_xy(spr, 1 / sq, sq)
        _blit_center(surf, spr, e.rect, cam_x, ox, oy)
    elif e.kind == "jumper":
        f = max(-0.2, min(0.2, -e.vy * 0.014))
        spr = _scale_xy(spr, 1 - f * 0.7, 1 + f)
        _blit_bottom(surf, spr, e.rect, cam_x, ox, oy)
    else:
        _blit_bottom(surf, spr, e.rect, cam_x, ox, oy)


def _draw_boss(surf, boss, assets, cam_x, ox, oy):
    spr = assets["boss"]
    if boss.dying:
        if (boss.death_timer // 3) % 2 == 0:
            return
    elif boss.invuln > 0 and (boss.invuln // 4) % 2 == 0:
        return
    dx, sx, sy = 0, 1.0, 1.0
    if boss.phase == "telegraph":
        dx = int(math.sin(boss.anim * 1.4) * 3)
    elif boss.phase == "stunned":
        sx, sy = 1.2, 0.7
    elif boss.phase == "slam":
        sx, sy = 0.9, 1.12
    img = _scale_xy(spr, sx, sy) if (sx, sy) != (1.0, 1.0) else spr
    surf.blit(img, (boss.rect.centerx - cam_x + ox - img.get_width() // 2 + dx,
                    boss.rect.bottom - img.get_height() + oy))
    if boss.phase == "telegraph" and (boss.anim // 4) % 2 == 0:           # предупреждение
        r = pygame.Rect(boss.rect.x - cam_x + ox - 2, boss.rect.y + oy - 2,
                        boss.rect.width + 4, boss.rect.height + 4)
        pygame.draw.rect(surf, (255, 60, 50), r, 3)
    if boss.phase == "stunned":                                          # звёздочки «оглушён»
        cx = boss.rect.centerx - cam_x + ox
        cy = boss.rect.top + oy - 8
        for k in range(3):
            a = boss.anim * 0.12 + k * 2.1
            pygame.draw.circle(surf, (255, 230, 80),
                               (cx + int(math.cos(a) * 18) + (k - 1) * 7, cy + int(math.sin(a) * 5)), 3)


def _draw_ant(surf, boss, cam_x, ox, oy):
    if boss.dying:
        if (boss.death_timer // 3) % 2 == 0:
            return
    elif boss.invuln > 0 and (boss.invuln // 4) % 2 == 0:
        return
    d = boss.dir
    cx = boss.rect.centerx - cam_x + ox
    top = boss.rect.top + oy
    bottom = boss.rect.bottom + oy
    midy = top + ANT_H * 0.52
    body, dark, shine = (96, 46, 30), (60, 28, 18), (138, 78, 50)

    legc = (45, 22, 14)                                       # 6 ног, анимация бега
    run = boss.phase == "run"
    for i in range(3):
        lx = cx + (i - 1) * 18
        sw = math.sin(boss.anim * 0.4 + i * 1.3) * (7 if run else 1.5)
        for side in (1, -1):
            pygame.draw.lines(surf, legc, False,
                              [(lx, midy + 4), (lx + side * 10, midy + 14),
                               (lx + side * 16 + sw, bottom - 1)], 4)

    gx = int(cx - d * ANT_W * 0.30)                           # брюшко
    gw, gh = int(ANT_W * 0.46), int(ANT_H * 0.82)
    gtop = int(midy - gh * 0.42)
    pygame.draw.ellipse(surf, body, (gx - gw // 2, gtop, gw, gh))
    pygame.draw.ellipse(surf, dark, (gx - gw // 2, gtop, gw, gh), 3)
    pygame.draw.ellipse(surf, shine, (gx - gw // 2 + 6, gtop + 5, gw // 3, gh // 3))

    tw, th = int(ANT_W * 0.30), int(ANT_H * 0.58)             # грудь
    pygame.draw.ellipse(surf, body, (cx - tw // 2, int(midy - th * 0.5), tw, th))
    pygame.draw.ellipse(surf, dark, (cx - tw // 2, int(midy - th * 0.5), tw, th), 2)

    hr = int(ANT_H * 0.34)                                    # голова (опускается в уязвимости)
    hx = int(cx + d * ANT_W * 0.34)
    hy = int(midy - hr * 0.2 + boss.head_drop * 20)
    pygame.draw.circle(surf, body, (hx, hy), hr)
    pygame.draw.circle(surf, dark, (hx, hy), hr, 3)

    for a in (0, 1):                                          # антенны
        pygame.draw.lines(surf, dark, False,
                          [(hx + d * 4, hy - hr + 2), (hx + d * (10 + a * 4), hy - hr - 4),
                           (hx + d * (16 + a * 8), hy - hr - 14 + a * 6)], 2)
        pygame.draw.circle(surf, (30, 18, 12), (hx + d * (16 + a * 8), hy - hr - 14 + a * 6), 3)

    ex = hx + d * 5                                           # глаз
    pygame.draw.circle(surf, (245, 245, 235), (ex, hy - 3), 5)
    pygame.draw.circle(surf, (20, 15, 10), (ex + d, hy - 3), 3)

    open_amt = 6 if boss.phase == "aim" else 2                # жвалы (раскрыты при прицеливании)
    mouthx = hx + d * (hr - 1)
    pygame.draw.line(surf, dark, (mouthx, hy + 2), (mouthx + d * 12, hy - open_amt), 3)
    pygame.draw.line(surf, dark, (mouthx, hy + 4), (mouthx + d * 12, hy + open_amt + 4), 3)

    if boss.phase == "aim":                                   # копит кислоту + предупреждение
        gr = max(4, 4 + int((ANT_AIM_TIME - boss.timer) * 0.18))
        sx = hx + d * (hr + 6)
        pygame.draw.circle(surf, (235, 215, 45), (sx, hy), gr)
        pygame.draw.circle(surf, (255, 245, 140), (sx - d, hy - 1), max(2, gr // 2))
        if (boss.anim // 4) % 2 == 0:
            pygame.draw.rect(surf, (255, 70, 50), (cx - 3, top - 26, 6, 14))
            pygame.draw.rect(surf, (255, 70, 50), (cx - 3, top - 9, 6, 5))

    if boss.phase == "stunned":                              # «оглушён» — бей по голове
        for k in range(3):
            ang = boss.anim * 0.12 + k * 2.1
            pygame.draw.circle(surf, (255, 230, 80),
                               (cx + int(math.cos(ang) * 20) + (k - 1) * 8, top - 6 + int(math.sin(ang) * 5)), 3)


def _draw_puddles(surf, game, cam_x, ox, oy):
    for p in game.puddles:
        r = p["rect"]
        if p["timer"] < 60 and (game.anim // 5) % 2 == 0:    # мигает перед исчезновением
            continue
        x = r.centerx - cam_x + ox
        y = r.bottom + oy
        w = r.width
        blob = pygame.Surface((w, 18), pygame.SRCALPHA)
        pygame.draw.ellipse(blob, (205, 195, 25, 205), (0, 4, w, 12))
        pygame.draw.ellipse(blob, (240, 230, 70, 235), (4, 2, w - 8, 9))
        surf.blit(blob, (x - w // 2, y - 14))
        for k in range(3):
            bx = x - w // 3 + k * (w // 3)
            by = y - 8 + int(math.sin(game.anim * 0.2 + k) * 2)
            pygame.draw.circle(surf, (255, 245, 120), (bx, by), 2)


def _draw_ant_spits(surf, game, cam_x, ox, oy):
    for s in game.ant_spits:
        x = s["rect"].centerx - cam_x + ox
        y = s["rect"].centery + oy
        pygame.draw.circle(surf, (225, 205, 35), (x, y), SPIT_R)
        pygame.draw.circle(surf, (255, 245, 130), (x - 2, y - 2), 3)
        pygame.draw.circle(surf, (150, 130, 10), (x, y), SPIT_R, 1)


def _draw_platform(surf, rect, cam_x, ox, oy):
    x = rect.x - cam_x + ox
    y = rect.y + oy
    pygame.draw.rect(surf, (150, 100, 55), (x, y, rect.width, rect.height))
    pygame.draw.rect(surf, (110, 70, 38), (x, y, rect.width, rect.height), 2)
    for dx in range(0, rect.width, 22):
        pygame.draw.line(surf, (120, 80, 45), (x + dx, y + 2), (x + dx, y + rect.height - 2), 1)
    pygame.draw.line(surf, (195, 145, 95), (x + 2, y + 2), (x + rect.width - 2, y + 2), 2)


def _draw_projectiles(surf, game, cam_x, ox, oy):
    for p in game.projectiles:
        cx = p["rect"].centerx - cam_x + ox
        cy = p["rect"].centery + oy
        pygame.draw.circle(surf, (255, 160, 40), (cx, cy), PROJ_R)
        pygame.draw.circle(surf, (255, 235, 130), (cx, cy), 3)
        pygame.draw.circle(surf, (180, 60, 10), (cx, cy), PROJ_R, 1)


def _draw_cloud_platform(surf, rect, cam_x, ox, oy):
    x = rect.x - cam_x + ox
    y = rect.y + oy
    pygame.draw.rect(surf, (248, 251, 255), (x, y, rect.width, rect.height))
    for i in range(0, rect.width - 8, 24):
        pygame.draw.circle(surf, (248, 251, 255), (x + i + 14, y + rect.height), 15)
    pygame.draw.circle(surf, (248, 251, 255), (x + rect.width - 12, y + rect.height - 2), 14)
    pygame.draw.line(surf, (210, 224, 242), (x, y), (x + rect.width, y), 2)


def _draw_tree(surf, bx, by, height, angle_deg, crown_r, cam_x, ox, oy):
    x = bx - cam_x + ox
    y = by + oy
    ang = math.radians(angle_deg)
    tx = x + height * math.sin(ang)
    ty = y - height * math.cos(ang)
    pygame.draw.line(surf, (110, 75, 45), (x, y), (tx, ty), TREE_TRUNK_W)
    pygame.draw.circle(surf, (55, 150, 65), (int(tx), int(ty)), crown_r)
    pygame.draw.circle(surf, (42, 120, 52), (int(tx), int(ty)), crown_r, 3)


def _draw_chick(surf, chick, assets, cam_x, ox, oy):
    spr = assets["chick"]
    if chick.facing < 0:
        spr = pygame.transform.flip(spr, True, False)
    bob = -round(abs(math.sin(chick.anim * 0.3)) * 3)
    _blit_bottom(surf, spr, chick.rect, cam_x, ox, oy, bob)


def _draw_player_shots(surf, game, cam_x, ox, oy):
    for s in game.player_shots:
        cx = s["rect"].centerx - cam_x + ox
        cy = s["rect"].centery + oy
        pygame.draw.circle(surf, (140, 230, 255), (cx, cy), SUPER_SHOT_R)
        pygame.draw.circle(surf, (255, 255, 255), (cx, cy), 4)
        pygame.draw.circle(surf, (60, 160, 230), (cx, cy), SUPER_SHOT_R, 1)


def _draw_particles(surf, game, cam_x, ox, oy):
    for p in game.particles:
        x = int(p["x"] - cam_x + ox)
        y = int(p["y"] + oy)
        sz = p.get("size", 5)
        col = p.get("color", (175, 125, 85))
        life0 = p.get("life0", p["life"]) or 1
        if p["life"] < life0 * 0.5:                  # к концу жизни — растворяется
            a = max(0, int(255 * p["life"] / (life0 * 0.5)))
            g = pygame.Surface((sz, sz), pygame.SRCALPHA)
            g.fill(col + (a,))
            surf.blit(g, (x, y))
        else:
            pygame.draw.rect(surf, col, (x, y, sz, sz))


def _draw_effects(surf, game, assets, cam_x, ox, oy):
    for fx in game.effects:
        p = 1 - fx["timer"] / fx["life"]
        sx = int(fx["x"] - cam_x + ox)
        sy = int(fx["y"] + oy)
        if p < 0.5:
            r = int(8 + p * 46)
            a = max(0, int(200 * (1 - p * 2)))
            flash = pygame.Surface((2 * r + 6, 2 * r + 6), pygame.SRCALPHA)
            pygame.draw.circle(flash, (255, 250, 190, a), (r + 3, r + 3), r, 3)
            surf.blit(flash, (sx - r - 3, sy - r - 3))
        txt = assets["small"].render(fx["text"], True, fx["color"])
        txt.set_alpha(int(255 * (1 - p)))
        surf.blit(txt, txt.get_rect(center=(sx, sy - int(p * 28))))


def _draw_sky_bg(surf, cam_x, ox, oy, assets):
    surf.blit(assets["sky_grad"], (0, 0))               # кэш-градиент неба
    pygame.draw.circle(surf, (255, 244, 150), (WIDTH - 110 + ox, 80 + oy), 46)
    pygame.draw.circle(surf, (255, 250, 200), (WIDTH - 110 + ox, 80 + oy), 46, 4)
    for hx, hr in HILLS:                                # дальние холмы — медленный параллакс
        x = int(hx * 0.6 - cam_x * 0.25 + ox)
        pygame.draw.circle(surf, (156, 198, 156), (x, GROUND_TOP + 26 + oy), hr - 4)
    for hx, hr in HILLS:                                # ближние холмы
        x = int(hx - cam_x * 0.5 + ox)
        pygame.draw.circle(surf, HILL_DARK, (x, GROUND_TOP + 10 + oy), hr)
        pygame.draw.circle(surf, HILL, (x, GROUND_TOP + 14 + oy), hr - 6)
    for cx, cy in CLOUDS:
        surf.blit(assets["cloud"], (cx - cam_x * 0.7 + ox, cy + oy))


def _draw_water_bg(surf, game, cam_x, ox, oy):
    # градиент толщи воды
    bands = 12
    for i in range(bands):
        t = i / (bands - 1)
        col = tuple(int(WATER_TOP_COL[k] + (WATER_BOT_COL[k] - WATER_TOP_COL[k]) * t) for k in range(3))
        y0 = oy + int(HEIGHT * i / bands)
        surf.fill(col, (0, y0, WIDTH + 2 * SHAKE_MARGIN, HEIGHT // bands + 2))
    # лучи света сверху
    for lx in range(0, game.level_w, 360):
        x = lx - int(cam_x * 0.6) + ox
        pygame.draw.polygon(surf, (90, 200, 235),
                            [(x, oy), (x + 40, oy), (x - 60, oy + 260), (x - 120, oy + 260)], 0)
    # водоросли (колышутся)
    for wx, wh in SEAWEED:
        x = wx - cam_x + ox
        if x < -30 or x > WIDTH + 2 * SHAKE_MARGIN + 30:
            continue
        pts = []
        for seg in range(0, wh, 10):
            sway = math.sin(game.anim * 0.05 + wx * 0.01 + seg * 0.1) * (seg / wh) * 12
            pts.append((x + sway, SEA_FLOOR - seg + oy))
        if len(pts) > 1:
            pygame.draw.lines(surf, (40, 160, 90), False, pts, 5)
            pygame.draw.lines(surf, (60, 190, 110), False, pts, 2)
    # кораллы на дне
    for cx, ctype in CORALS:
        x = cx - cam_x + ox
        if x < -40 or x > WIDTH + 2 * SHAKE_MARGIN + 40:
            continue
        col = CORAL_COLORS[ctype]
        base = SEA_FLOOR + oy
        pygame.draw.circle(surf, col, (x, base - 8), 12)
        pygame.draw.circle(surf, col, (x - 12, base - 4), 9)
        pygame.draw.circle(surf, col, (x + 12, base - 5), 10)
        pygame.draw.circle(surf, col, (x, base - 22), 8)
    # пузыри
    for i, bx in enumerate(BUBBLE_COLS):
        x = bx - cam_x + ox
        if x < -20 or x > WIDTH + 2 * SHAKE_MARGIN + 20:
            continue
        for k in range(4):
            ph = (game.anim * 1.6 + i * 37 + k * 60) % 240
            by = SEA_FLOOR - ph + oy
            bxx = x + int(math.sin((ph + i * 30) * 0.05) * 7)
            pygame.draw.circle(surf, (210, 240, 255), (bxx, int(by)), 3 + (k % 3), 1)


def _draw_ice_bg(surf, game, cam_x, ox, oy):
    surf.fill(ICE_SKY)
    pygame.draw.circle(surf, (236, 246, 252), (WIDTH - 110 + ox, 80 + oy), 44)
    for hx, hr in HILLS:
        x = int(hx - cam_x * 0.5 + ox)
        pygame.draw.circle(surf, (210, 226, 240), (x, GROUND_TOP + 12 + oy), hr)
        pygame.draw.circle(surf, (236, 246, 252), (x, GROUND_TOP + 16 + oy), hr - 6)
    span_w = WIDTH + 2 * SHAKE_MARGIN
    span_h = HEIGHT + 2 * SHAKE_MARGIN
    for i in range(42):                              # снежинки
        sx = (i * 137 - int(game.anim * (1.1 + i % 3 * 0.4))) % span_w
        sy = (i * 83 + int(game.anim * (1.4 + i % 4))) % span_h
        pygame.draw.circle(surf, (250, 252, 255), (sx, sy), 2)


def _draw_icicles(surf, game, cam_x, ox, oy):
    half = ICICLE_W // 2
    for ic in game.icicles:
        x = int(ic["x"] - cam_x + ox)
        y = int(ic["y"] + oy)
        pts = [(x - half, y), (x + half, y), (x, y + ICICLE_H)]
        pygame.draw.polygon(surf, (120, 190, 235), pts)                          # насыщенное тело — контраст с бледным фоном
        pygame.draw.polygon(surf, (185, 222, 248),                               # светлый клин для объёма
                            [(x - half + 2, y), (x + 1, y), (x, y + ICICLE_H - 6)])
        pygame.draw.polygon(surf, (35, 85, 145), pts, 3)                         # тёмная обводка — резкий силуэт
        pygame.draw.line(surf, (250, 253, 255), (x - 2, y + 3), (x, y + ICICLE_H - 8), 2)  # яркий блик


def _draw_house_bg(surf, game, cam_x, ox, oy):
    span = WIDTH + 2 * SHAKE_MARGIN
    surf.fill((208, 178, 138))                                       # тёплые обои
    for x in range(-(int(cam_x * 0.4) % 70), span, 70):              # вертикальные полосы обоев
        pygame.draw.line(surf, (197, 167, 127), (x, oy), (x, GROUND_TOP + oy), 3)
    pygame.draw.rect(surf, (176, 146, 108), (0, oy, span, 8))        # потолочный бордюр
    for wx0 in (520, 1400, 2200):                                    # окна: ночь + луна (parallax)
        x = int(wx0 - cam_x * 0.5) + ox
        if x < -180 or x > span + 40:
            continue
        pygame.draw.rect(surf, (58, 60, 96), (x, 72 + oy, 150, 128))
        pygame.draw.circle(surf, (245, 240, 215), (x + 112, 104 + oy), 16)       # луна
        for sxx, syy in [(20, 30), (54, 92), (122, 44), (40, 64), (90, 28)]:
            pygame.draw.circle(surf, (220, 222, 240), (x + sxx, oy + 72 + syy), 1)
        pygame.draw.rect(surf, (236, 226, 200), (x - 6, 66 + oy, 162, 140), 6)   # рама
        pygame.draw.line(surf, (236, 226, 200), (x + 75, 72 + oy), (x + 75, 200 + oy), 4)
        pygame.draw.line(surf, (236, 226, 200), (x, 136 + oy), (x + 150, 136 + oy), 4)
    pygame.draw.rect(surf, (150, 120, 86), (0, GROUND_TOP - 10 + oy, span, 10))  # плинтус


def _draw_cat(surf, assets, lc, cam_x, ox, oy):
    cat = lc.cat
    sh = pygame.Surface((cat.width, 14), pygame.SRCALPHA)                        # тень
    pygame.draw.ellipse(sh, (0, 0, 0, 80), sh.get_rect())
    surf.blit(sh, (cat.centerx - cam_x + ox - cat.width // 2, lc.floor + oy - 9))
    spr = pygame.transform.smoothscale(assets["kot"], (CAT_W, CAT_H))
    if lc.facing < 0:
        spr = pygame.transform.flip(spr, True, False)
    if lc.phase == "leap":
        spr = pygame.transform.rotate(spr, -lc.facing * 12)
    surf.blit(spr, spr.get_rect(center=(cat.centerx - cam_x + ox, cat.centery + oy)))


def _draw_laser(surf, lc, cam_x, ox, oy):
    dx = int(lc.dot_x - cam_x + ox)
    dy = int(lc.dot_y + oy)
    fr = lc.frenzy
    if lc.phase in ("chase", "aim", "recover"):                                  # луч из потолка
        pygame.draw.line(surf, (255, 60, 60), (dx - 8, oy - SHAKE_MARGIN), (dx, dy), 4 if fr else 2)
    if lc.phase == "aim":                                                        # маркер прыжка
        mx, my = int(lc.target_x - cam_x + ox), int(lc.target_y + oy)
        if (lc.anim // (2 if fr else 4)) % 2 == 0:                               # в рывке мигает чаще
            pygame.draw.circle(surf, (255, 60, 60), (mx, my - 16), 20, 3)
            pygame.draw.line(surf, (255, 60, 60), (mx - 26, my - 16), (mx + 26, my - 16), 2)
            pygame.draw.line(surf, (255, 60, 60), (mx, my - 42), (mx, my + 10), 2)
    pulse = (6 if fr else 4) + int(2 * math.sin(lc.anim * (0.8 if fr else 0.4)))
    glow = pygame.Surface((pulse * 4 + 4, pulse * 4 + 4), pygame.SRCALPHA)
    pygame.draw.circle(glow, (255, 60, 60, 130 if fr else 110), (pulse * 2 + 2, pulse * 2 + 2), pulse * 2)
    surf.blit(glow, (dx - pulse * 2 - 2, dy - pulse * 2 - 2))
    pygame.draw.circle(surf, (255, 70, 70), (dx, dy), pulse)
    pygame.draw.circle(surf, (255, 225, 225), (dx, dy), max(1, pulse - 3))
    if fr:                                                                       # рывок — кольцо-тревога
        pygame.draw.circle(surf, (255, 95, 95), (dx, dy), pulse + 5, 2)


def _draw_cellar_bg(surf, game, cam_x, ox, oy):
    span = WIDTH + 2 * SHAKE_MARGIN
    surf.fill((54, 48, 46))                                          # тёмный погреб
    bw, bh = 70, 34                                                  # каменная кладка
    for ry, y in enumerate(range(oy - bh, GROUND_TOP + oy, bh)):
        shift = (bw // 2) if (ry % 2) else 0
        for x in range(-bw, span + bw, bw):
            rx = x + shift
            pygame.draw.rect(surf, (70, 62, 58), (rx, y, bw - 3, bh - 3))
            pygame.draw.rect(surf, (44, 38, 36), (rx, y, bw - 3, bh - 3), 2)
    for lx0 in (300, 1100, 1900, 2700):                             # тусклые лампочки под потолком
        x = int(lx0 - cam_x * 0.6) + ox
        if -50 < x < span + 50:
            glow = pygame.Surface((96, 96), pygame.SRCALPHA)
            pygame.draw.circle(glow, (255, 220, 140, 45), (48, 48), 44)
            surf.blit(glow, (x - 48, oy + 24))
            pygame.draw.line(surf, (38, 32, 30), (x, oy), (x, oy + 26), 2)
            pygame.draw.circle(surf, (255, 226, 150), (x, oy + 32), 7)
    pygame.draw.rect(surf, (40, 34, 32), (0, GROUND_TOP - 8 + oy, span, 8))  # плинтус


def _draw_boulders(surf, game, cam_x, ox, oy):
    for b in game.boulders:
        x = b["rect"].centerx - cam_x + ox
        y = b["rect"].centery + oy
        r = b["r"]
        if x < -r - 40 or x > WIDTH + 2 * SHAKE_MARGIN + r + 40:
            continue
        sh = pygame.Surface((2 * r, 14), pygame.SRCALPHA)                    # тень
        pygame.draw.ellipse(sh, (0, 0, 0, 90), sh.get_rect())
        surf.blit(sh, (x - r, GROUND_TOP + oy - 8))
        pygame.draw.circle(surf, (240, 200, 70), (x, y), r)                  # тело-сыр
        pygame.draw.circle(surf, (205, 160, 40), (x, y), r, 3)
        for k in range(5):                                                  # дырки вращаются
            a = b["spin"] + k * 1.26
            hx = x + int(math.cos(a) * r * 0.5)
            hy = y + int(math.sin(a) * r * 0.5)
            pygame.draw.circle(surf, (214, 168, 44), (hx, hy), max(2, r // 7))
            pygame.draw.circle(surf, (188, 146, 34), (hx, hy), max(2, r // 7), 1)


def _draw_rainbow_bg(surf, cam_x, ox, oy, assets):
    span = WIDTH + 2 * SHAKE_MARGIN
    top, bot = (175, 222, 255), (255, 224, 246)                      # пастельный градиент неба
    bands = 10
    for i in range(bands):
        t = i / (bands - 1)
        col = tuple(int(top[k] + (bot[k] - top[k]) * t) for k in range(3))
        surf.fill(col, (0, oy + int(HEIGHT * i / bands), span, HEIGHT // bands + 2))
    arc = [(255, 95, 95), (255, 175, 70), (255, 235, 90), (110, 215, 130), (90, 175, 255), (175, 115, 235)]
    ccx = int(WIDTH * 0.5 - cam_x * 0.3) + ox
    ccy = GROUND_TOP + oy + 70
    for i, c in enumerate(arc):                                      # радуга-арка на фоне
        pygame.draw.circle(surf, c, (ccx, ccy), 330 - i * 16, 10)
    for cx, cy in CLOUDS:
        surf.blit(assets["cloud"], (int(cx - cam_x * 0.6) + ox, cy + oy))


def _draw_wheel(surf, wheel, cam_x, ox, oy):
    cx = wheel["cx"] - cam_x + ox
    cy = wheel["cy"] + oy
    r = wheel["r"]
    n = len(wheel["spokes"])
    ang = wheel["spokes"][0].angle
    pygame.draw.circle(surf, (236, 240, 255), (cx, cy), r + 4, 4)        # обод
    for k in range(n):                                                  # спицы
        a = ang + k * (2 * math.pi / n)
        pygame.draw.line(surf, (205, 214, 242), (cx, cy),
                         (cx + int(math.cos(a) * r), cy + int(math.sin(a) * r)), 3)
    pygame.draw.circle(surf, (255, 226, 90), (cx, cy), 9)               # ось
    pygame.draw.circle(surf, (214, 170, 45), (cx, cy), 9, 2)


def _draw_spoke(surf, rect, cam_x, ox, oy):
    x = rect.x - cam_x + ox
    y = rect.y + oy
    cols = [(255, 95, 95), (255, 180, 70), (255, 235, 90), (110, 215, 130), (90, 180, 255), (180, 120, 240)]
    bw = max(1, rect.width // len(cols))
    for i, c in enumerate(cols):
        pygame.draw.rect(surf, c, (x + i * bw, y, bw + 1, rect.height))
    pygame.draw.rect(surf, (255, 255, 255), (x, y, rect.width, rect.height), 2)
    pygame.draw.line(surf, (255, 255, 255), (x + 2, y + 2), (x + rect.width - 3, y + 2), 1)


def _ground_below(game, rect):
    """Y верхней грани ближайшей опоры под объектом (для падающей тени)."""
    cx = rect.centerx
    best = LEVEL_H + 100
    for r, k in game.solids:
        if r.left <= cx <= r.right and r.top >= rect.bottom - 4:
            best = min(best, r.top)
    for m in game.movers:
        if m.rect.left <= cx <= m.rect.right and m.rect.top >= rect.bottom - 4:
            best = min(best, m.rect.top)
    return best


def _draw_shadow(surf, assets, rect, cam_x, ox, oy, ground_y):
    if ground_y > LEVEL_H + 60:
        return
    height = max(0, ground_y - rect.bottom)              # выше над землёй — тень меньше
    scale = max(0.45, 1.0 - height / 620)
    w = max(8, int(rect.width * 1.3 * scale))
    h = max(4, int(w * 0.3))
    surf.blit(pygame.transform.scale(assets["shadow"], (w, h)),
              (rect.centerx - cam_x + ox - w // 2, ground_y + oy - h // 2))


RAINBOW = [(255, 90, 90), (255, 175, 65), (255, 235, 85),
           (105, 215, 130), (85, 175, 255), (175, 115, 235)]


def _draw_unicorn(surf, boss, cam_x, ox, oy):
    if boss.dying:
        if (boss.death_timer // 3) % 2 == 0:
            return
    elif boss.invuln > 0 and (boss.invuln // 4) % 2 == 0:     # мигает после удара
        return
    d = boss.dir
    cx = boss.rect.centerx - cam_x + ox
    top = boss.rect.top + oy
    bottom = boss.rect.bottom + oy
    midy = top + UNI_H * 0.5
    white, out, shade = (250, 250, 255), (198, 192, 216), (228, 224, 240)

    run = boss.phase == "move"                                # ноги (4) с шагом при ходьбе
    for i in range(4):
        lx = cx + (i - 1.5) * (UNI_W * 0.17)
        sw = math.sin(boss.anim * 0.3 + i * 1.6) * (8 if run else 1.5)
        pygame.draw.line(surf, out, (lx, midy + 12), (lx + sw, bottom - 2), 11)
        pygame.draw.line(surf, white, (lx, midy + 12), (lx + sw, bottom - 2), 7)
        pygame.draw.circle(surf, (236, 222, 150), (int(lx + sw), bottom - 2), 5)   # копыто

    tx = cx - d * int(UNI_W * 0.42)                           # радужный хвост (сзади)
    for i, c in enumerate(RAINBOW):
        sway = math.sin(boss.anim * 0.12 + i * 0.5) * 6
        pygame.draw.line(surf, c, (tx, midy - 6),
                         (tx - d * (14 + i * 2), midy + 18 + i * 5 + sway), 5)

    bw, bh = int(UNI_W * 0.66), int(UNI_H * 0.62)             # тело
    brect = (cx - bw // 2, int(midy - bh * 0.5), bw, bh)
    pygame.draw.ellipse(surf, white, brect)
    pygame.draw.ellipse(surf, out, brect, 3)
    pygame.draw.ellipse(surf, shade, (cx - bw // 2 + 8, int(midy + bh * 0.18), bw - 16, 11))

    drop = boss.head_drop * 26                                # голова опускается в уязвимости
    neck_x = cx + d * int(UNI_W * 0.26)
    neck_top = int(midy - bh * 0.34 + drop)
    head_cx = cx + d * int(UNI_W * 0.42)
    head_cy = int(midy - bh * 0.24 + drop)
    pygame.draw.polygon(surf, white, [                        # шея
        (cx + d * int(UNI_W * 0.12), int(midy - bh * 0.30)),
        (neck_x, neck_top - 6),
        (head_cx, head_cy + 4),
        (cx + d * int(UNI_W * 0.16), int(midy + bh * 0.12))])
    hw, hh = int(UNI_W * 0.27), int(UNI_H * 0.30)             # голова + морда
    hrect = (head_cx - hw // 2, head_cy - hh // 2, hw, hh)
    pygame.draw.ellipse(surf, white, hrect)
    muzzle = (head_cx + (d * hw // 2 if d > 0 else d * hw // 2 - hw // 2),
              head_cy - 3, hw // 2, hh // 2 + 2)
    pygame.draw.ellipse(surf, white, muzzle)
    pygame.draw.ellipse(surf, out, hrect, 3)
    pygame.draw.polygon(surf, white, [                        # ухо
        (head_cx - d * 4, head_cy - hh // 2 + 2),
        (head_cx - d * 11, head_cy - hh // 2 - 12),
        (head_cx + d * 2, head_cy - hh // 2 - 1)])
    for i, c in enumerate(RAINBOW):                           # радужная грива вдоль шеи
        mx = cx + d * int(UNI_W * 0.12) + d * i * 5
        pygame.draw.line(surf, c, (mx, int(midy - bh * 0.32) - 2),
                         (mx + d * 6, neck_top + i * 3 + 2), 5)
    eye = (head_cx + d * 4, head_cy - 2)                      # глаз
    pygame.draw.circle(surf, (45, 30, 55), eye, 4)
    pygame.draw.circle(surf, (255, 255, 255), (eye[0] - d, eye[1] - 1), 1)

    hb = (head_cx + d * int(hw * 0.34), head_cy - hh // 2 + 2)    # золотой рог
    htip = (head_cx + d * int(hw * 0.74), head_cy - hh // 2 - 28 + int(drop))
    pygame.draw.polygon(surf, (255, 215, 90),
                        [(hb[0] - d * 4, hb[1]), (hb[0] + d * 4, hb[1]), htip])
    pygame.draw.polygon(surf, (220, 170, 40),
                        [(hb[0] - d * 4, hb[1]), (hb[0] + d * 4, hb[1]), htip], 1)
    pygame.draw.line(surf, (220, 170, 40), hb, htip, 1)

    if boss.glow > 0.02:                                      # свечение рога при заряде/луче
        gr = int(8 + boss.glow * 22)
        g = pygame.Surface((gr * 2, gr * 2), pygame.SRCALPHA)
        col = RAINBOW[int(boss.anim * 0.3) % len(RAINBOW)]
        for rr, a in ((gr, 70), (gr * 2 // 3, 120), (gr // 3, 210)):
            pygame.draw.circle(g, col + (int(a * boss.glow),), (gr, gr), max(1, rr))
        surf.blit(g, (htip[0] - gr, htip[1] - gr))

    if boss.phase == "charge" and (boss.anim // 4) % 2 == 0:  # предупреждение «!»
        pygame.draw.rect(surf, (255, 70, 60), (cx - 4, top - 36, 8, 18))
        pygame.draw.rect(surf, (255, 70, 60), (cx - 4, top - 14, 8, 6))
    if boss.phase == "stunned":                              # звёздочки «оглушён»
        for k in range(4):
            ang = boss.anim * 0.12 + k * 1.7
            pygame.draw.circle(surf, (255, 230, 80),
                               (cx + int(math.cos(ang) * 26) + int((k - 1.5) * 9),
                                top - 12 + int(math.sin(ang) * 6)), 3)


def _draw_unicorn_beam(surf, boss, cam_x, ox, oy):
    if boss.phase not in ("charge", "beam"):
        return
    if boss.phase == "charge":                              # телеграф: линия прицела прямо в игрока
        hx, hy = boss.horn_pos()
        sx, sy = hx - cam_x + ox, hy + oy
        ang = boss.aim_angle
        ex, ey = sx + math.cos(ang) * UNI_BEAM_LEN, sy + math.sin(ang) * UNI_BEAM_LEN
        col = (255, 110, 110) if (boss.anim // 4) % 2 == 0 else (255, 220, 130)
        pygame.draw.line(surf, col, (sx, sy), (ex, ey), 3)
        return
    ang = boss.beam_angle                                   # beam: радужный луч под углом в игрока
    bx, by = boss.beam_origin
    sx, sy = bx - cam_x + ox, by + oy
    dx, dy = math.cos(ang), math.sin(ang)
    ex, ey = sx + dx * UNI_BEAM_LEN, sy + dy * UNI_BEAM_LEN
    nx, ny = -dy, dx                                        # перпендикуляр — для толщины
    bright = (boss.anim // 2) % 2
    half = (len(RAINBOW) - 1) / 2
    for i, c in enumerate(RAINBOW):
        off = (i - half) / half * UNI_BEAM_HALF
        col = tuple(min(255, v + 30) for v in c) if bright else c
        pygame.draw.line(surf, col, (sx + nx * off, sy + ny * off),
                         (ex + nx * off, ey + ny * off), 7)
    pygame.draw.line(surf, (255, 255, 255), (sx, sy), (ex, ey), 5)   # белое ядро


def draw_world(surf, game, assets, cam_x, ox, oy):
    if game.underwater:
        _draw_water_bg(surf, game, cam_x, ox, oy)
    elif game.icy:
        _draw_ice_bg(surf, game, cam_x, ox, oy)
    elif game.level == 12:
        _draw_house_bg(surf, game, cam_x, ox, oy)
    elif game.level == 13:
        _draw_cellar_bg(surf, game, cam_x, ox, oy)
    elif game.level in (14, 15):
        _draw_rainbow_bg(surf, cam_x, ox, oy, assets)
    else:
        _draw_sky_bg(surf, cam_x, ox, oy, assets)

    for dx, dh in game.decor_trees:                   # деревья на фоне (разной высоты)
        _draw_tree(surf, dx, GROUND_TOP, dh, 0.0, int(dh * 0.3), cam_x, ox, oy)

    for rect, kind in game.solids:
        if kind == "cloudbase":
            _draw_cloud_platform(surf, rect, cam_x, ox, oy)
            continue
        tex = assets[kind]
        for tx in range(rect.left, rect.right, TILE):
            sx = tx - cam_x + ox
            if sx <= -TILE or sx >= WIDTH + 2 * SHAKE_MARGIN:
                continue
            for ty in range(rect.top, rect.bottom, TILE):
                surf.blit(tex, (sx, ty + oy))

    _draw_puddles(surf, game, cam_x, ox, oy)

    for w in game.wheels:                             # ось+спицы колеса (под лопастями)
        _draw_wheel(surf, w, cam_x, ox, oy)
    for m in game.movers:
        if m.visual == "cloud":
            _draw_cloud_platform(surf, m.rect, cam_x, ox, oy)
        elif m.visual == "spoke":
            _draw_spoke(surf, m.rect, cam_x, ox, oy)
        else:
            _draw_platform(surf, m.rect, cam_x, ox, oy)

    for t in game.trees:                              # падающие/упавшие деревья
        _draw_tree(surf, t.base_x, t.ground_y, t.height, t.draw_angle(), t.crown_r, cam_x, ox, oy)

    for c in game.coins:
        cx = c.centerx - cam_x + ox
        if cx < -20 or cx > WIDTH + 2 * SHAKE_MARGIN + 20:
            continue
        cy = c.centery + oy
        g = assets["glow"]                                # мягкое свечение монеты (кэш)
        surf.blit(g, (cx - g.get_width() // 2, cy - g.get_height() // 2))
        hw = max(2, int(9 * abs(math.cos(game.anim * 0.12 + c.x * 0.04))))
        pygame.draw.ellipse(surf, (255, 205, 40), (cx - hw, cy - 9, hw * 2, 18))
        pygame.draw.ellipse(surf, (200, 150, 20), (cx - hw, cy - 9, hw * 2, 18), 1)
        if hw > 5:
            pygame.draw.ellipse(surf, (255, 240, 160), (cx - hw + 2, cy - 6, max(1, hw - 3), 5))

    if game.powerup is not None:                          # собираемый предмет-усилитель
        r = game.powerup
        cx = r.centerx - cam_x + ox
        cy = r.centery + oy + int(math.sin(game.anim * 0.1) * 3)
        if game.powerup_kind == "high":                   # «сырок» = высокий прыжок
            pygame.draw.circle(surf, (245, 205, 70), (cx, cy), 13)
            pygame.draw.circle(surf, (255, 255, 255), (cx, cy), 13, 2)
            pygame.draw.circle(surf, (214, 168, 44), (cx - 5, cy + 3), 2)   # дырки сыра
            pygame.draw.circle(surf, (214, 168, 44), (cx + 5, cy - 2), 2)
            pygame.draw.lines(surf, (255, 255, 255), False,                 # стрелка вверх
                              [(cx - 6, cy + 5), (cx, cy - 6), (cx + 6, cy + 5)], 3)
            pygame.draw.line(surf, (255, 255, 255), (cx, cy - 6), (cx, cy + 6), 3)
        else:                                             # жетон двойного прыжка
            pygame.draw.circle(surf, (120, 220, 255), (cx, cy), 13)
            pygame.draw.circle(surf, (255, 255, 255), (cx, cy), 13, 2)
            for d in (-3, 4):                             # два шеврона вверх = двойной прыжок
                pygame.draw.lines(surf, (255, 255, 255), False,
                                  [(cx - 6, cy + d + 2), (cx, cy + d - 3), (cx + 6, cy + d + 2)], 2)

    if game.boss is None:
        fx = game.flag.centerx - cam_x + ox
        ftop = game.flag.top + oy
        if game.underwater:                           # светящийся выход-портал
            for rr, col in [(34, (120, 240, 255)), (24, (180, 250, 255)), (14, (240, 255, 255))]:
                glow = pygame.Surface((rr * 2 + 4, rr * 2 + 4), pygame.SRCALPHA)
                a = 120 + int(60 * math.sin(game.anim * 0.1))
                pygame.draw.circle(glow, col + (a,), (rr + 2, rr + 2), rr)
                surf.blit(glow, (int(fx) - rr - 2, game.win_zone.centery + oy - rr - 2))
        else:
            pygame.draw.rect(surf, (225, 225, 225), (fx - 3, ftop, 6, game.flag.height))
            pygame.draw.circle(surf, (255, 215, 0), (int(fx), ftop), 8)
            pygame.draw.polygon(surf, (40, 200, 90),
                                [(fx + 3, ftop + 10), (fx + 3, ftop + 42), (fx + 52, ftop + 26)])

    if not game.underwater:                          # мягкие тени под персонажами (над платформами)
        shadowed = [e.rect for e in game.enemies if e.alive and e.kind not in ("fish", "emedusa")]
        if game.chick is not None and game.chick.alive:
            shadowed.append(game.chick.rect)
        if game.lasercat is not None:
            shadowed.append(game.lasercat.cat)
        if game.boss is not None and game.boss.alive:
            shadowed.append(game.boss.rect)
        shadowed.append(game.player)
        for r in shadowed:
            _draw_shadow(surf, assets, r, cam_x, ox, oy, _ground_below(game, r))

    for e in game.enemies:
        if e.alive or e.dying:
            _draw_enemy(surf, e, assets, cam_x, ox, oy)

    if game.boss is not None and (game.boss.alive or game.boss.dying):
        kind = getattr(game.boss, "kind", "")
        if kind == "ant":
            _draw_ant(surf, game.boss, cam_x, ox, oy)
        elif kind == "unicorn":
            _draw_unicorn(surf, game.boss, cam_x, ox, oy)
            _draw_unicorn_beam(surf, game.boss, cam_x, ox, oy)   # поверх платформ — «сквозь» них
        else:
            _draw_boss(surf, game.boss, assets, cam_x, ox, oy)
    if game.lasercat is not None:
        _draw_cat(surf, assets, game.lasercat, cam_x, ox, oy)
    _draw_ant_spits(surf, game, cam_x, ox, oy)

    _draw_projectiles(surf, game, cam_x, ox, oy)
    if game.chick is not None and game.chick.alive:
        _draw_chick(surf, game.chick, assets, cam_x, ox, oy)
    _draw_particles(surf, game, cam_x, ox, oy)
    if game.boulders:
        _draw_boulders(surf, game, cam_x, ox, oy)

    if not (game.invuln > 0 and (game.anim // 4) % 2 == 0):
        _draw_player(surf, game, assets, cam_x, ox, oy)

    _draw_player_shots(surf, game, cam_x, ox, oy)
    _draw_icicles(surf, game, cam_x, ox, oy)
    if game.lasercat is not None:
        _draw_laser(surf, game.lasercat, cam_x, ox, oy)
    _draw_effects(surf, game, assets, cam_x, ox, oy)
    surf.blit(assets["vignette"], (0, 0))                # лёгкое затемнение краёв кадра


def _draw_heart(screen, x, y, filled):
    color = (230, 60, 70) if filled else (95, 95, 100)
    pygame.draw.circle(screen, color, (x + 7, y + 7), 7)
    pygame.draw.circle(screen, color, (x + 19, y + 7), 7)
    pygame.draw.polygon(screen, color, [(x, y + 9), (x + 26, y + 9), (x + 13, y + 25)])


def draw_hud(screen, game, assets):
    for i in range(game.max_lives):
        _draw_heart(screen, 16 + i * 34, 14, i < game.lives)
    if game.test_mode:
        t = assets["small"].render("ТЕСТ", True, (40, 120, 220))
        screen.blit(t, (16 + game.max_lives * 34 + 4, 18))
    score_s = assets["font"].render(f"СЧЁТ: {game.score}", True, (20, 40, 60))
    screen.blit(score_s, (WIDTH - score_s.get_width() - 16, 12))
    lvl = assets["font"].render(f"УРОВЕНЬ {game.level}", True, (20, 40, 60))
    screen.blit(lvl, lvl.get_rect(midtop=(WIDTH // 2, 12)))
    if game.boss is not None:                         # сердца босса — справа
        maxhp = getattr(game.boss, "max_hp", BOSS_HP)
        bx = WIDTH - 16 - maxhp * 30
        label = assets["small"].render("БОСС", True, (210, 60, 50))
        screen.blit(label, (bx - label.get_width() - 8, 48))
        for i in range(maxhp):
            _draw_heart(screen, bx + i * 30, 44, i < game.boss.hp)
    if game.quake_timer > 0 and (game.anim // 6) % 2 == 0:
        q = assets["font"].render("!! ЗЕМЛЕТРЯСЕНИЕ !!", True, (210, 50, 40))
        screen.blit(q, q.get_rect(midtop=(WIDTH // 2, 44)))
    if game.super_mode:
        sp = assets["small"].render("СУПЕР! Enter — выстрел", True, (60, 160, 230))
        screen.blit(sp, sp.get_rect(midtop=(WIDTH // 2, 76)))
    snd = "M звук" if SOUND_ON else "M звук:ВЫКЛ"
    if game.underwater:
        hint = f"Стрелки — плыть    R рестарт    T тест    {snd}    Esc выход"
    else:
        hint = f"Стрелки — ходить    Вверх/Пробел — прыжок    R рестарт    {snd}    Esc выход"
    screen.blit(assets["small"].render(hint, True, (30, 50, 70)), (16, HEIGHT - 24))
    if game.toast_timer > 0:                              # ненавязчивое уведомление
        toast = assets["font"].render(game.toast_text, True, (70, 170, 235))
        toast.set_alpha(min(255, game.toast_timer * 6))
        screen.blit(toast, toast.get_rect(center=(WIDTH // 2, HEIGHT - 72)))
    if game.level_banner_timer > 0:                       # крупная плашка «УРОВЕНЬ N»
        t = game.level_banner_timer
        banner = assets["big"].render(f"УРОВЕНЬ {game.level}", True, (255, 255, 255))
        plate = pygame.Surface((banner.get_width() + 64, banner.get_height() + 28), pygame.SRCALPHA)
        plate.fill((0, 0, 0, min(140, t * 5)))
        prect = plate.get_rect(center=(WIDTH // 2, HEIGHT // 2 - 50))
        screen.blit(plate, prect)
        banner.set_alpha(min(255, t * 8))
        screen.blit(banner, banner.get_rect(center=prect.center))


def _draw_choice_list(screen, assets, options, index, cy0, sel_col, norm_col, step=48):
    for i, opt in enumerate(options):
        sel = (i == index)
        text = ("> " if sel else "   ") + opt + (" <" if sel else "")
        label = assets["font"].render(text, True, sel_col if sel else norm_col)
        screen.blit(label, label.get_rect(center=(WIDTH // 2, cy0 + i * step)))


def draw_overlay(screen, game, assets):                  # экран победы
    if game.state != "win":
        return
    overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
    overlay.fill((0, 0, 0, 150))
    screen.blit(overlay, (0, 0))
    label = assets["big"].render("ПОБЕДА!", True, (120, 240, 130))
    screen.blit(label, label.get_rect(center=(WIDTH // 2, HEIGHT // 2 - 20)))
    sub = assets["font"].render("Нажми R, чтобы начать заново", True, (235, 235, 235))
    screen.blit(sub, sub.get_rect(center=(WIDTH // 2, HEIGHT // 2 + 40)))


def draw_lose_dialog(screen, game, assets):
    overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
    overlay.fill((0, 0, 0, 165))
    screen.blit(overlay, (0, 0))
    label = assets["big"].render("ИГРА ОКОНЧЕНА", True, (255, 120, 110))
    screen.blit(label, label.get_rect(center=(WIDTH // 2, 175)))
    _draw_choice_list(screen, assets, game.lose_options(), game.menu_index, 300,
                      (255, 205, 90), (225, 225, 225))
    hint = assets["small"].render("Стрелки — выбор    Enter — подтвердить", True, (205, 215, 225))
    screen.blit(hint, hint.get_rect(center=(WIDTH // 2, HEIGHT - 50)))


def draw_settings(screen, game, assets):
    screen.fill((150, 180, 210))
    title = assets["big"].render("НАСТРОЙКИ", True, (40, 60, 90))
    screen.blit(title, title.get_rect(center=(WIDTH // 2, 130)))
    _draw_choice_list(screen, assets, game.settings_options(), game.menu_index, 260,
                      (230, 90, 60), (50, 70, 100), step=52)
    hint = assets["small"].render("Стрелки — выбор    Enter — изменить    Esc — назад",
                                  True, (50, 70, 100))
    screen.blit(hint, hint.get_rect(center=(WIDTH // 2, HEIGHT - 40)))


def draw_menu(screen, game, assets):
    screen.fill(SKY)
    for cx, cy in [(140, 90), (560, 70), (820, 180)]:
        screen.blit(assets["cloud"], (cx, cy))
    title = assets["big"].render("БУБУЗА — ПЛАТФОРМЕР", True, (40, 70, 110))
    screen.blit(title, title.get_rect(center=(WIDTH // 2, 110)))
    hero = pygame.transform.smoothscale(assets["bubuza"], (66, 70))
    screen.blit(hero, hero.get_rect(center=(WIDTH // 2, 218)))
    for i, opt in enumerate(game.menu_options()):
        sel = (i == game.menu_index)
        col = (230, 90, 60) if sel else (60, 80, 110)
        text = ("> " if sel else "   ") + opt + (" <" if sel else "")
        label = assets["font"].render(text, True, col)
        screen.blit(label, label.get_rect(center=(WIDTH // 2, 312 + i * 46)))
    hint = assets["small"].render("Стрелки — выбор    Enter — подтвердить    Esc — выход",
                                  True, (50, 70, 100))
    screen.blit(hint, hint.get_rect(center=(WIDTH // 2, HEIGHT - 22)))


# =====================================================================
#  Сенсорное управление (touch) + геймпад
# =====================================================================

TOUCH_JUMP  = pygame.Rect(92, 396, 96, 96)         # прыжок / вверх — слева, ближе к центру
TOUCH_DOWN  = pygame.Rect(204, 414, 76, 76)        # «вниз» (плавание, ур.4) — слева
TOUCH_SHOOT = pygame.Rect(204, 320, 76, 76)        # супер-выстрел — слева, выше
TOUCH_LEFT  = pygame.Rect(688, 404, 84, 86)        # движение — справа, ближе к центру
TOUCH_RIGHT = pygame.Rect(784, 404, 84, 86)
GAMEPAD_DEADZONE = 0.4


def _touch_buttons(game):
    """Активные сенсорные кнопки для текущего состояния игры."""
    btns = [("left", TOUCH_LEFT), ("right", TOUCH_RIGHT), ("jump", TOUCH_JUMP)]
    if game.underwater:
        btns.append(("down", TOUCH_DOWN))
    if game.super_mode:
        btns.append(("shoot", TOUCH_SHOOT))
    return btns


def _touch_at(pos, game):
    for name, r in _touch_buttons(game):
        if r.collidepoint(pos):
            return name
    return None


def _finger_pos(event):
    return (int(event.x * WIDTH), int(event.y * HEIGHT))


def _menu_item_at(pos, st, n):
    """Индекс пункта меню/диалога под точкой касания (или None)."""
    cy0, step = {"menu": (312, 46), "settings": (260, 52), "lose": (300, 48)}[st]
    for i in range(n):
        if abs(pos[1] - (cy0 + i * step)) <= step // 2:
            return i
    return None


def _gamepad_dir(joys):
    """(left, right, up, down) из стиков/крестовины всех геймпадов."""
    lx = ly = 0.0
    for j in joys:
        if j.get_numaxes() > 0:
            lx += j.get_axis(0)
        if j.get_numaxes() > 1:
            ly += j.get_axis(1)
        if j.get_numhats() > 0:
            hx, hy = j.get_hat(0)
            lx += hx
            ly -= hy
    dz = GAMEPAD_DEADZONE
    return (lx < -dz, lx > dz, ly < -dz, ly > dz)


def _draw_touch_btn(screen, r, name):
    surf = pygame.Surface((r.width, r.height), pygame.SRCALPHA)
    rad = min(r.width, r.height) // 2
    pygame.draw.circle(surf, (255, 255, 255, 55), (r.width // 2, r.height // 2), rad)
    pygame.draw.circle(surf, (255, 255, 255, 120), (r.width // 2, r.height // 2), rad, 3)
    screen.blit(surf, r.topleft)
    cx, cy = r.center
    ink = (35, 50, 75)
    if name == "left":
        pygame.draw.polygon(screen, ink, [(cx + 11, cy - 15), (cx - 13, cy), (cx + 11, cy + 15)])
    elif name == "right":
        pygame.draw.polygon(screen, ink, [(cx - 11, cy - 15), (cx + 13, cy), (cx - 11, cy + 15)])
    elif name == "down":
        pygame.draw.polygon(screen, ink, [(cx - 15, cy - 11), (cx + 15, cy - 11), (cx, cy + 13)])
    elif name == "jump":
        pygame.draw.polygon(screen, ink, [(cx - 16, cy + 12), (cx + 16, cy + 12), (cx, cy - 14)])
    elif name == "shoot":
        pygame.draw.circle(screen, (255, 120, 60), (cx, cy), 15)
        pygame.draw.circle(screen, (255, 235, 160), (cx, cy), 7)


def draw_touch_controls(screen, game):
    if not game.touch_ui or game.state != "play":
        return
    for name, r in _touch_buttons(game):
        _draw_touch_btn(screen, r, name)


def _dialog_opts(game, st):
    return (game.menu_options() if st == "menu" else
            game.settings_options() if st == "settings" else game.lose_options())


def _touch_press(game, pos, tid, active):
    """Обработать касание/клик. Возвращает 'jump' | 'quit' | None."""
    st = game.state
    if st == "play":
        btn = _touch_at(pos, game)
        if btn == "shoot":
            game.super_shoot()
            return None
        if btn:
            active[tid] = btn
            return "jump" if btn == "jump" else None
        return None
    if st == "win":
        game.reset()
        return None
    opts = _dialog_opts(game, st)
    idx = _menu_item_at(pos, st, len(opts))
    if idx is not None:
        game.menu_index = idx
        if game.select_option(opts[idx]):
            return "quit"
    return None


# =====================================================================
#  Точка входа
# =====================================================================

async def main():
    global SOUND_ON
    if not IS_WEB and _ensure_numpy():
        try:                        # низкая задержка + стерео под синтез
            pygame.mixer.pre_init(44100, -16, 2, 512)
        except pygame.error:
            pass
    pygame.init()
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption("Мини-платформер")
    clock = pygame.time.Clock()

    try:                            # геймпад опционален (в браузере может отсутствовать)
        pygame.joystick.init()
        joys = [pygame.joystick.Joystick(i) for i in range(pygame.joystick.get_count())]
        for j in joys:
            j.init()
    except Exception:
        joys = []

    assets = build_assets()
    if not IS_WEB:                  # звук через numpy — только на десктопе (в вебе не тянем numpy)
        build_sounds()
        if "music" in SOUNDS:
            SOUNDS["music"].set_volume(0.4)
            SOUNDS["music"].play(loops=-1)
    game = Game()
    buffer = pygame.Surface((WIDTH + 2 * SHAKE_MARGIN, HEIGHT + 2 * SHAKE_MARGIN))

    DIALOG = ("menu", "settings", "lose")
    active_touch = {}                    # id касания -> имя удерживаемой кнопки
    running = True
    while running:
        jump = False
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
                continue
            if event.type in (pygame.JOYDEVICEADDED, pygame.JOYDEVICEREMOVED):
                try:
                    joys = [pygame.joystick.Joystick(i) for i in range(pygame.joystick.get_count())]
                    for j in joys:
                        j.init()
                except Exception:
                    joys = []
                continue
            st = game.state

            # --- сенсор: палец / мышь ---
            if event.type in (pygame.FINGERDOWN, pygame.MOUSEBUTTONDOWN):
                game.touch_ui = True
                if event.type == pygame.FINGERDOWN:
                    pos, tid = _finger_pos(event), ("f", event.finger_id)
                else:
                    pos, tid = event.pos, "mouse"
                act = _touch_press(game, pos, tid, active_touch)
                if act == "jump":
                    jump = True
                elif act == "quit":
                    running = False
                continue
            if event.type in (pygame.FINGERUP, pygame.MOUSEBUTTONUP):
                active_touch.pop(("f", event.finger_id) if event.type == pygame.FINGERUP else "mouse", None)
                continue
            if event.type == pygame.FINGERMOTION and st == "play":
                tid = ("f", event.finger_id)
                if tid in active_touch:
                    active_touch[tid] = _touch_at(_finger_pos(event), game) or active_touch[tid]
                continue
            if event.type == pygame.MOUSEMOTION and st == "play":
                if event.buttons[0] and "mouse" in active_touch:
                    active_touch["mouse"] = _touch_at(event.pos, game) or active_touch["mouse"]
                continue

            # --- геймпад: кнопки и крестовина ---
            if event.type == pygame.JOYBUTTONDOWN:
                if st in DIALOG:
                    opts = _dialog_opts(game, st)
                    if event.button == 0 and game.select_option(opts[game.menu_index]):
                        running = False
                elif st == "win":
                    if event.button == 0:
                        game.reset()
                else:
                    if event.button in (0, 3):              # A / Y — прыжок
                        jump = True
                    elif event.button in (1, 2):            # B / X — выстрел
                        game.super_shoot()
                continue
            if event.type == pygame.JOYHATMOTION and st in DIALOG:
                opts = _dialog_opts(game, st)
                if event.value[1] > 0:
                    game.menu_index = (game.menu_index - 1) % len(opts)
                elif event.value[1] < 0:
                    game.menu_index = (game.menu_index + 1) % len(opts)
                continue

            # --- клавиатура ---
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_m:
                    SOUND_ON = not SOUND_ON
                    try:
                        pygame.mixer.unpause() if SOUND_ON else pygame.mixer.pause()
                    except pygame.error:
                        pass
                    continue
                if st in DIALOG:
                    opts = _dialog_opts(game, st)
                    if event.key in (pygame.K_UP, pygame.K_LEFT):
                        game.menu_index = (game.menu_index - 1) % len(opts)
                    elif event.key in (pygame.K_DOWN, pygame.K_RIGHT):
                        game.menu_index = (game.menu_index + 1) % len(opts)
                    elif event.key in (pygame.K_RETURN, pygame.K_SPACE):
                        if game.select_option(opts[game.menu_index]):
                            running = False
                    elif event.key == pygame.K_ESCAPE:
                        if st == "menu":
                            running = False
                        else:
                            game.state = "menu"
                            game.menu_index = 0
                else:
                    if event.key == pygame.K_ESCAPE:
                        running = False
                    elif event.key in (pygame.K_UP, pygame.K_SPACE):
                        jump = True
                    elif event.key == pygame.K_r and st == "win":
                        game.reset()
                    elif event.key == pygame.K_t:
                        game.test_mode = not game.test_mode
                        game.lives = game.max_lives
                    elif event.key == pygame.K_RETURN:
                        game.super_shoot()

        if game.state == "menu":
            draw_menu(screen, game, assets)
            pygame.display.flip(); clock.tick(FPS)
            await asyncio.sleep(0)
            continue
        if game.state == "settings":
            draw_settings(screen, game, assets)
            pygame.display.flip(); clock.tick(FPS)
            await asyncio.sleep(0)
            continue

        if game.state == "play":            # клавиши + сенсор + геймпад
            keys = pygame.key.get_pressed()
            held = set(active_touch.values())
            gl, gr, gu, gd = _gamepad_dir(joys)
            left = keys[pygame.K_LEFT] or ("left" in held) or gl
            right = keys[pygame.K_RIGHT] or ("right" in held) or gr
            up = keys[pygame.K_UP] or ("jump" in held) or gu
            down = keys[pygame.K_DOWN] or ("down" in held) or gd
            game.update(left, right, up, down, jump)

        target_cam = max(0, min(game.player.centerx - WIDTH // 2, max(0, game.level_w - WIDTH)))
        game.cam_x += (target_cam - game.cam_x) * 0.14      # плавное слежение камеры
        cam_x = round(game.cam_x)
        shake_x = shake_y = 0
        if game.state == "play" and game.quake_timer > 0:
            shake_x = random.uniform(-QUAKE_AMP, QUAKE_AMP)
            shake_y = random.uniform(0, QUAKE_AMP)
        draw_world(buffer, game, assets, cam_x, SHAKE_MARGIN, SHAKE_MARGIN)
        screen.blit(buffer, (round(shake_x) - SHAKE_MARGIN, round(shake_y) - SHAKE_MARGIN))
        draw_hud(screen, game, assets)
        draw_touch_controls(screen, game)
        if game.state == "win":
            draw_overlay(screen, game, assets)
        elif game.state == "lose":
            draw_lose_dialog(screen, game, assets)
        pygame.display.flip()
        clock.tick(FPS)
        await asyncio.sleep(0)          # уступаем браузеру (обязательно для pygbag)

    pygame.quit()


if __name__ == "__main__":
    asyncio.run(main())
